/**
 * 
 */
package org.xmlrobot.subspace;

import org.xmlrobot.subspace.mass.Hypermap;
import org.xmlrobot.subspace.mass.Hyperset;

/**
 * @author joan
 *
 */
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Hypermap map = new Hypermap(Hyperset.class, 'A', new Integer('A'));
//		Hypermap map2 = new Hypermap(Hyperset.class, 'B', 200, map, (Hyperset) map.getValue(), Parity.XY);
//		Hypermap map3 = new Hypermap(Hyperset.class, 'C', 400, map2, (Hyperset) map2.getValue(), Parity.XY);
//		Hypermap map4 = new Hypermap(Hyperset.class, 'D', 500, map3, (Hyperset) map3.getValue(), Parity.XY);
//		Hypermap map5 = new Hypermap(Hyperset.class, 'E', 600, map4, (Hyperset) map4.getValue(), Parity.XY);
//		Hypermap map6 = new Hypermap(Hyperset.class, 'F', 700, map5, (Hyperset) map5.getValue(), Parity.XY);
//		Hypermap map7 = new Hypermap(Hyperset.class, 'G', 800, map6, (Hyperset) map6.getValue(), Parity.XY);
		
		map.put('B', new Integer('B'));
		map.put('C', new Integer('C'));
//		map.put('D', new Integer('D'));
//		map.put('E', new Integer('E'));
//		map.put('F', new Integer('F'));
//		map.put('G', new Integer('G'));
//		map.put('H', new Integer('H'));
//		map.put('I', new Integer('I'));
//		map.put('J', new Integer('J'));
		
//		for(Metatext<Character, Integer> m : map) {
//			System.out.print(m.getFrom());	
//		}
		
		System.out.print(map.get().isPast());
	}
}
