/**
 * 
 */
/**
 * @author joan
 *
 */
package org.xmlrobot.subspace.event;