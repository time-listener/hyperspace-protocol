package org.xmlrobot.subspace.mass;

import javax.xml.bind.annotation.XmlRootElement;

import org.osgi.framework.ServiceEvent;
import org.xmlrobot.lang.Hyperinteger;
import org.xmlrobot.metatext.MetaSet;
import org.xmlrobot.util.Parity;

/**
 * A {@link Hyperentry} that is {@link MetaSet}.
 * {@link Integer} is the key. {@link Character} is the value.
 * @author joan
 *
 */
@XmlRootElement
public final class Hyperset extends Hyperinteger {

	/**
	 * 2776973801628200812L
	 */
	private static final long serialVersionUID = 2776973801628200812L;

	/* (non-Javadoc)
	 * @see org.xmlrobot.subspace.matter.Hyperentry#getName()
	 */
	@Override
	public String getName() {
		return characterArrayToString(toArray());
	}

	/**
	 * 
	 */
	public Hyperset() {
		super();
	}	
	/**
	 * {@link Hyperset} class constructor.
	 * @param key {@link Integer} the key
	 * @param value {@link Character} the value
	 */
	public Hyperset(Integer key, Character value) {
		super(Hyperset.class, key, value, Parity.XX);
	}
	/**
	 * {@link Hyperset} class constructor.
	 * @param antitype the antitype
	 * @param key {@link Integer} the key
	 * @param value {@link Character} the value
	 */
    public Hyperset(Class<Hypermap> antitype, Integer key, Character value) {
		super(Hyperset.class, antitype, key, value, Parity.XX);
	}
    /**
	 * {@link Hyperset} class constructor.
	 * @param key {@link Integer} the key
	 * @param value {@link Character} the value
	 * @param parent {@link Hyperset} the parent
	 * @param child {@link Hypermap} the child
	 */
    public Hyperset(Integer key, Character value, Hyperset parent, Hypermap child) {
		super(Hyperset.class, key, value, parent, child);
	}
    /**
	 * {@link Hyperset} class constructor.
	 * @param type the type
	 * @param key {@link Integer} the key
	 * @param value {@link Character} the value
	 * @param parent {@link Hyperset} the parent
	 * @param child {@link Hypermap} the child
	 */
    public Hyperset(Class<Hypermap> antitype, Integer key, Character value, Hyperset parent, Hypermap child) {
		super(Hyperset.class, antitype, key, value, parent, child);
	}
    /**
	 * {@link Hyperset} class constructor.
	 * @param key {@link Integer} the key
	 * @param value {@link Character} the value
	 * @param root {@link Hyperset} the root
	 * @param stem {@link Hypermap} the stem
	 * @param gen {@link Parity} the gender
	 */
    public Hyperset(Integer key, Character value, Hyperset root, Hypermap stem, Parity gen) {
		super(Hyperset.class, key, value, root, stem, gen);
	}
    /**
	 * {@link Hyperset} class constructor.
	 * @param type the type
	 * @param key {@link Integer} the key
	 * @param value {@link Character} the value
	 * @param root {@link Hyperset} the root
	 * @param stem {@link Hypermap} the stem
	 * @param gen {@link Parity} the gender
	 */
    public Hyperset(Class<Hypermap> antitype, Integer key, Character value, Hyperset root, Hypermap stem, Parity gen) {
		super(Hyperset.class, antitype, key, value, root, stem, gen);
	}
	
	@Override
	public void serviceChanged(ServiceEvent event) {
		
	}
}