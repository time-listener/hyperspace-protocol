/**
 * 
 */
/**
 * @author joan
 *
 */
@XmlSchema(
namespace = "http://xmlrobot.org/subspace/", elementFormDefault = XmlNsForm.QUALIFIED,
	xmlns=
	{
		@XmlNs(prefix="subspace", namespaceURI="http://xmlrobot.org/subspace/"),
		@XmlNs(prefix="xs", namespaceURI="http://www.w3.org/2001/XMLSchema")
	}
)
package org.xmlrobot.subspace;

import javax.xml.bind.annotation.XmlSchema;
import javax.xml.bind.annotation.*;
