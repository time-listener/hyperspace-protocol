package org.xmlrobot.subspace.event;

import org.xmlrobot.horizon.Meta;
import org.xmlrobot.metatext.Metatext;

public class Unfold extends Meta<Integer,Character> {

	/**
	 * 3074429996508128602L
	 */
	private static final long serialVersionUID = 3074429996508128602L;

	public Unfold(Metatext<Integer,Character> source) {
		super(source);
	}

}
