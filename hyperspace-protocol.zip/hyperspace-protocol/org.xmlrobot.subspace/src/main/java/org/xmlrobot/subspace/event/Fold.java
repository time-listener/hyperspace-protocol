package org.xmlrobot.subspace.event;

import org.xmlrobot.horizon.Meta;
import org.xmlrobot.metatext.Metatext;

public class Fold extends Meta<Character,Integer> {

	/**
	 * 1007564912947039155L
	 */
	private static final long serialVersionUID = 1007564912947039155L;

	public Fold(Metatext<Character,Integer> source) {
		super(source);
	}

}
