package org.xmlrobot.subspace.q;

public class QSubroot {

	public QSubroot() {
		// TODO Auto-generated constructor stub
	}

}
