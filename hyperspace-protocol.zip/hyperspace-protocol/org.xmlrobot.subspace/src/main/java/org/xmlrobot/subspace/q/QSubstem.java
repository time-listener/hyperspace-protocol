package org.xmlrobot.subspace.q;

public class QSubstem {

	public QSubstem() {
		// TODO Auto-generated constructor stub
	}

}
