/**
 * 
 */
package org.xmlrobot.genesis;

/**
 * A {@link DNA} {@link Sequence}.
 * @author joan
 *
 */
public interface Entity<K,V,X,Y> 
	extends DNA<K,V,X,Y>, Sequence<K,V,X,Y> {
}
