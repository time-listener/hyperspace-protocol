/**
 * 
 */
/**
 * @author joan
 *
 */
package org.xmlrobot.util;