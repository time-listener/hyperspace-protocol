/**
 * 
 */
package org.xmlrobot.util;


/**
 * @author joan
 *
 */
public interface BigData extends Information {

	void add(java.lang.Number value);
}