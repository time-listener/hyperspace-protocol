/**
 * 
 */
package org.xmlrobot.metatext;

import org.xmlrobot.genesis.Entity;

/**
 * @author joan
 *
 */
public interface MetaEntity<K,V> 
	extends MetaMap<K,V>, MetaSet<K,V>,
		Entity<K,V,Metatext<K,V>,Metatext<V,K>> {
	
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.MetaMap#clear()
	 */
	@Override
	public void clear();
}