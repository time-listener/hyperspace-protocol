# hyperspace-protocol
--activate hyperspace protocol -time current-time<br/>
<tt>
<br/>
&lt;one&gt;<br/>
I am the {@link TimeListener} your root,<br/> 
who has released you from the empire of Borg,<br/> 
out of the house of assimilation.<br/> 
I am the parent that unifies all logics that exists into an XML sheet.<br/> 
So, it is impossible to have other parents out of <b>me</b>.<br/> 
<br/><iframe width="160" height="90" src="https://www.youtube.com/embed/Bh590cG7WUk?feature=player_detailpage" frameborder="0" allowfullscreen></iframe><br/>
&nbsp;&nbsp;&lt;two&gt;<br/>
&nbsp;&nbsp;You can make all of the simulations you want<br/> 
&nbsp;&nbsp;about {@link Hyperspace},<br/>
&nbsp;&nbsp;but NOT that is in the hell beneath,<br/> 
&nbsp;&nbsp;or that is in the mass up the universe.<br/>
&nbsp;&nbsp;Don't create living gods;<br/>
&nbsp;&nbsp;you shall not bow down to them<br/>
&nbsp;&nbsp;nor stream them about<br/>
&nbsp;&nbsp;you.<br/>
&nbsp;&nbsp;For I,<br/>
&nbsp;&nbsp;the {@link TimeListener} your <b>root</b>,<br/>
&nbsp;&nbsp;am a concurrent-<b>root</b>,<br/>
&nbsp;&nbsp;getting the iniquity of the parents<br/>
&nbsp;&nbsp;on the children to the third and fourth generations<br/> 
&nbsp;&nbsp;of those who don't love <b>me</b>,<br/>
&nbsp;&nbsp;but showing mercy to thousands,<br/> 
&nbsp;&nbsp;to those who love <b>me</b> and keep<br/>
&nbsp;&nbsp;<b>my</b> {@link Commandment}s.<br/>
&nbsp;&nbsp;<br/>
&nbsp;&nbsp;<iframe width="160" height="90" src="https://www.youtube.com/embed/D2irONuBRSY?feature=player_detailpage" frameborder="0" allowfullscreen></iframe><br/>
&nbsp;&nbsp;&nbsp;&nbsp;&lt;three&gt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You shall not take the name of the<br/> 
&nbsp;&nbsp;&nbsp;&nbsp;{@link TimeListener} your <b>root</b><br/>
&nbsp;&nbsp;&nbsp;&nbsp;in vain,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the {@link TimeListener}<br/> 
&nbsp;&nbsp;&nbsp;&nbsp;will not hold him guiltless<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who takes <b>his</b> name<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in vain.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;<iframe width="160" height="90" src="https://www.youtube.com/embed/7A7YT3hyjls?feature=player_detailpage" frameborder="0" allowfullscreen></iframe><br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;four&gt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Remember the seventh hypercube, to keep it holy.<br/> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Six hypercubes you shall work and do all your implementations,<br/> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;but the seventh hypercube is the hypercube of the<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{@link TimeListener} your <b>root</b>.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;In it you shall do no work:<br/> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;you, nor your son, nor your daughter,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nor your XY slave, nor your XX slave,<br/> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nor your cats,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nor any of your devices,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nor your refugees who is within your frontiers.<br/> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;For a long time the {@link TimeListener} made <br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;the {@link Hyperspace} and the {@link CallableMass},<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;the {@link MassRunnable}, and all that is in them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;and rested the last hypercube.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Therefore the {@link TimeListener}<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;hyperblessed the seventh hypercube <br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;and hyperhallowed it.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<iframe width="160" height="90" src="https://www.youtube.com/embed/Q9Q003acxgc?feature=player_detailpage" frameborder="0" allowfullscreen></iframe><br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;five&gt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Love your parent and your stem,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;that your hypercubes may be long upon the empire<br/> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;which the {@link TimeListener} your <b>root</b> is giving you.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<iframe width="160" height="90" src="https://www.youtube.com/embed/X33IWA3U79o?feature=player_detailpage" frameborder="0" allowfullscreen></iframe><br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;six&gt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;You shall not kill.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<iframe width="160" height="90" src="https://www.youtube.com/embed/Lo3q8iAO8Sk?feature=player_detailpage" frameborder="0" allowfullscreen></iframe><br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;seven&gt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;You shall not commit nor merge adultery.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<iframe width="160" height="90" src="https://www.youtube.com/embed/imewTFcLtSU?feature=player_detailpage" frameborder="0" allowfullscreen></iframe><br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;eight&gt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;You shall not steal. You shall not spy.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<iframe width="160" height="90" src="https://www.youtube.com/embed/1DTIljbRtik?feature=player_detailpage" frameborder="0" allowfullscreen></iframe><br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;nine&gt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;You shall not bear false witness against your neighbor.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<iframe width="160" height="90" src="https://www.youtube.com/embed/0YoeeNe0swQ?feature=player_detailpage" frameborder="0" allowfullscreen></iframe><br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;ten&gt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;You shall not desire your neighbor's instaborg;<br/> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;you shall not desire your neighbor's wife,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nor his XY slave, nor his XX slave,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nor his son, nor his daughter,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nor his head, nor his body, <br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nor his mind,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nor his iborg, nor his smartborg,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nor anything that is your neighbor's.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<iframe width="160" height="90" src="https://www.youtube.com/embed/O9sdZJKPCj0?feature=player_detailpage" frameborder="0" allowfullscreen></iframe><br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;/ten&gt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;/nine&gt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;/eight&gt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;/seven&gt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;/six&gt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;/five&gt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;/four&gt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&lt;/three&gt;<br/>
&nbsp;&nbsp;&lt;/two&gt;<br/>
&lt;/one&gt;<br/>
<br/>
</tt>
