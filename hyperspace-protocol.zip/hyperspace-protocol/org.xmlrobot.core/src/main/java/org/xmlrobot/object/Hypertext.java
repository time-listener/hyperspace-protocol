/**
 * 
 */
package org.xmlrobot.object;

import java.util.Arrays;
import java.util.concurrent.atomic.AtomicInteger;

import org.xmlrobot.MassListener;
import org.xmlrobot.horizon.Mass;
import org.xmlrobot.horizon.Meta;
import org.xmlrobot.metatext.Metatext;
import org.xmlrobot.protocol.Hypermessage;
import org.xmlrobot.time.Time;
import org.xmlrobot.util.Abort;
import org.xmlrobot.util.Congregation;
import org.xmlrobot.util.Parity;

/**
 * @author joan
 *
 */
public abstract class Hypertext<K,V> 
	extends Time<Metatext<K,V>,Metatext<V,K>> 
		implements Metatext<K,V> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 111389494968134557L;
	
	protected volatile Hypermessage<K,V> message;

	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.PastMeta#getFromArray()
	 */
	@Override
	public K[] fromArray() {
		return message.fromArray();
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.PastMeta#setFromArray(java.lang.Object[])
	 */
	@Override
	public void fromArray(K[] array) {
		message.fromArray(array);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.MetaFuture#getToArray()
	 */
	@Override
	public V[] toArray() {
		return message.toArray();
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.MetaFuture#setToArray(java.lang.Object[])
	 */
	@Override
	public void toArray(V[] array) {
		message.toArray(array);
	}

	/**
	 * 
	 */
	public Hypertext() {
		super();
	}
	/**
	 * {@link Hypertext} class constructor.
	 * @param type the type
     * @param fromType the from type
	 * @param from the from
	 * @param to the to
	 * @param gen {@link Parity} the gender
	 */
    protected Hypertext(
    		Class<? extends Metatext<K,V>> type, 
    		Class<K[]> fromType,
    		K from, V to,
    		Parity gen) {
		super(type, gen);
		// initialize message
		message = new Hypermessage<K,V>(super.dna(), fromType, from, to);
	}
	/**
	 * {@link Hypertext} class constructor.
	 * @param type the type
	 * @param value the value
     * @param fromType the from type
	 * @param from the from
	 * @param to the to
	 * @param gen {@link Parity} the gender
	 */
    protected Hypertext(
    		Class<? extends Metatext<K,V>> type, 
    		Metatext<V,K> value, 
    		Class<K[]> fromType,
    		K from, V to,
    	    Parity gen) {
		super(type, value, gen);
		// initialize message
		message = new Hypermessage<K,V>(super.dna(), fromType, value, from, to);
	}
    /**
	 * {@link Hypertext} class constructor.
	 * @param type the type
	 * @param from the from
	 * @param to the to
	 * @param parent the root
	 * @param child the stem
	 */
    protected Hypertext(
    		Class<? extends Metatext<K,V>> type, 
    		K from, V to, 
    		Metatext<K,V> parent, 
    		Metatext<V,K> child) {
		super(type, parent, child);
		// initialize message
		message = new Hypermessage<K,V>(super.dna(), from, to);
	}
    /**
	 * {@link Hypertext} class constructor.
	 * @param type the type
	 * @param value the value
	 * @param from the from
	 * @param to the negative
	 * @param parent the root
	 * @param child the stem
	 */
    protected Hypertext(
    		Class<? extends Metatext<K,V>> type,
    		Metatext<V,K> value, 
    		K from, V to, 
    		Metatext<K,V> parent, 
    		Metatext<V,K> child) {
		super(type, value, parent, child);
		// initialize message
		message = new Hypermessage<K,V>(super.dna(), from, to);
	}
    /**
	 * {@link Hypertext} class constructor.
	 * @param type the type
	 * @param from the from
	 * @param to the to
	 * @param root the parent
	 * @param stem the child
	 * @param gen {@link Parity} the gender
	 */
    protected Hypertext(
    		Class<? extends Metatext<K,V>> type, 
    		K from, V to, 
    		Metatext<K,V> root, 
    		Metatext<V,K> stem, 
    		Parity gen) {
		super(type, root, stem, gen);
		// initialize message
		message = new Hypermessage<K,V>(super.dna(), from, to);
	}
    /**
	 * {@link Hypertext} class constructor.
	 * @param type the type
	 * @param value the value
	 * @param from the from
	 * @param to the to
	 * @param parent the parent
	 * @param child the child
	 * @param gen {@link Parity} the gender
	 */
    protected Hypertext(
    		Class<? extends Metatext<K,V>> type,
    		Metatext<V,K> value, 
    		K from, V to,  
    		Metatext<K,V> parent,
    		Metatext<V,K> child, 
    		Parity gen) {
		super(type, value, parent, child, gen);
		// initialize message
		message = new Hypermessage<K,V>(super.dna(), from, to);
	}
    
	/* (non-Javadoc)
	 * @see org.xmlrobot.hyperspace.Recursion#clone()
	 */
	@Override
	public Metatext<K,V> clone() {
		try {
			Hypertext<K,V> clone = (Hypertext<K,V>) super.clone();
			if(message.getFrom() == null)
				clone.message = new Hypermessage<K,V>(clone.data);
			else clone.message = new Hypermessage<K,V>(clone.data, message.getFrom(), message.getTo());
			return clone;
		}
		catch (ClassCastException | NullPointerException | Abort a) {

			return null;
		}
	}
	/* (non-Javadoc)
     * @see org.xmlrobot.Hypergenesis#dna()
     */
    @Override
    public Hypermessage<K,V> dna() {
    	return message.dna();
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.Metatext#containsTo(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public boolean containsTo(MassListener sender, Mass<V> event) {
		switch (getGen()) {
		case XY:
			return holdsTo(sender, event);
		case XX:
			return belongsTo(sender, event);
		default:
			return hasTo(sender, event);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.Metatext#containsFrom(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public boolean containsFrom(MassListener sender, Mass<K> event) {
		switch (getGen()) {
		case XY:
			return belongsFrom(sender, event);
		case XX:
			return holdsFrom(sender, event);
		default:
			return hasFrom(sender, event);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.Metatext#excerptFrom(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger, java.util.concurrent.atomic.AtomicInteger, org.xmlrobot.util.Congregation)
	 */
	@Override
	public Congregation<K> excerptFrom(MassListener sender,	AtomicInteger beginIndex, AtomicInteger endIndex, Congregation<K> event) {// check start index
		switch (getGen()) {
		case XY:
			return substringFrom(sender, beginIndex, endIndex, event);
		case XX:
			return subsequenceFrom(sender, beginIndex, endIndex, event);
		default:
			return subchainFrom(sender, beginIndex, endIndex, event);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.Metatext#excerptTo(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger, java.util.concurrent.atomic.AtomicInteger, org.xmlrobot.util.Congregation)
	 */
	@Override
	public Congregation<V> excerptTo(MassListener sender, AtomicInteger beginIndex, AtomicInteger endIndex, Congregation<V> event) {
		switch (getGen()) {
		case XY:
			return subsequenceTo(sender, beginIndex, endIndex, event);
		case XX:
			return substringTo(sender, beginIndex, endIndex, event);
		default:
			return subchainTo(sender, beginIndex, endIndex, event);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.Metatext#getFrom(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public Mass<K> getFrom(MassListener sender, Mass<V> event) {
		switch (getGen()) {
		case XY:
			return requestFrom(sender, event);
		case XX:
			return acquireFrom(sender, event);
		default:
			return callFrom(sender, event);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.Metatext#getTo(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public Mass<V> getTo(MassListener sender, Mass<K> event) {
		switch (getGen()) {
		case XY:
			return acquireTo(sender, event);
		case XX:
			return requestTo(sender, event);
		default:
			return callTo(sender, event);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.Metatext#getTo(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger)
	 */
	@Override
	public Mass<V> getTo(MassListener sender, AtomicInteger N) {
		switch (getGen()) {
		case XY:
			return acquireTo(sender, N);
		case XX:
			return requestTo(sender, N);
		default:
			return callTo(sender, N);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.Metatext#getFrom(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger)
	 */
	@Override
	public Mass<K> getFrom(MassListener sender, AtomicInteger N) {
		switch (getGen()) {
		case XY:
			return requestFrom(sender, N);
		case XX:
			return acquireFrom(sender, N);
		default:
			return callFrom(sender, N);
		}
	}

	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.Metatext#indexOfTo(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public AtomicInteger indexOfTo(MassListener sender, Mass<V> event) {
		switch (getGen()) {
		case XY:
			return pointerOfTo(sender, event);
		case XX:
			return positionOfTo(sender, event);
		default:
			return orderOfTo(sender, event);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.Metatext#indexOfFrom(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public AtomicInteger indexOfFrom(MassListener sender, Mass<K> event) {
		switch (getGen()) {
		case XY:
			return positionOfFrom(sender, event);
		case XX:
			return pointerOfFrom(sender, event);
		default:
			return orderOfFrom(sender, event);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.Metatext#removeFrom(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger)
	 */
	@Override
	public void removeFrom(MassListener sender, AtomicInteger N) {
		// commute by gender
		switch (getGen()) {
		case XY:
			super.liberateKey(sender, N);
			return;
		case XX:
			super.releaseKey(sender, N);
			return;
		default:
			super.redeemKey(sender, N);
			return;
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.Metatext#removeTo(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger)
	 */
	@Override
	public void removeTo(MassListener sender, AtomicInteger N) {
		// commute by gender
		switch (getGen()) {
		case XY:
			super.releaseValue(sender, N);
			return;
		case XX:
			super.liberateValue(sender, N);
			return;
		default:
			super.redeemValue(sender, N);
			return;
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.Metatext#removeTo(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public void removeTo(MassListener sender, AtomicInteger N, Mass<V> event) {
		switch (getGen()) {
		case XY:
			releaseTo(sender, N, event);
			return;
		case XX:
			liberateTo(sender, N, event);
			return;
		default:
			redeemTo(sender, N, event);
			return;
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.Metatext#removeFrom(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public void removeFrom(MassListener sender, AtomicInteger N, Mass<K> event) {
		switch (getGen()) {
		case XY:
			liberateFrom(sender, N, event);
			return;
		case XX:
			releaseFrom(sender, N, event);
			return;
		default:
			redeemFrom(sender, N, event);
			return;
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.Metatext#addTo(org.xmlrobot.MassListener, org.xmlrobot.horizon.Meta)
	 */
	@Override
	public void setTo(MassListener sender, Meta<V,K> event) {
		switch (getGen()) {
		case XY:
			super.submitValue(sender, event);
			return;
		case XX:
			super.injectValue(sender, event);
			return;
		default:
			super.pushValue(sender, event);
			return;
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.Metatext#addFrom(org.xmlrobot.MassListener, org.xmlrobot.horizon.Meta)
	 */
	@Override
	public void setFrom(MassListener sender, Meta<K,V> event) {
		switch (getGen()) {
		case XY:
			super.injectKey(sender, event);
			return;
		case XX:
			super.submitKey(sender, event);
			return;
		default:
			super.pushKey(sender, event);
			return;
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.Metatext#setFrom(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger, org.xmlrobot.horizon.Meta)
	 */
	@Override
	public Meta<K,V> setFrom(MassListener sender, AtomicInteger N, Meta<K,V> event) {
		switch (getGen()) {
		case XY:
			return (Meta<K,V>) super.updateKey(sender, N, event);
		case XX:
			return (Meta<K,V>) super.assignKey(sender, N, event);
		default:
			return (Meta<K,V>) super.putKey(sender, N, event);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.Metatext#setTo(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger, org.xmlrobot.horizon.Meta)
	 */
	@Override
	public Meta<V,K> setTo(MassListener sender, AtomicInteger N, Meta<V,K> event) {
		switch (getGen()) {
		case XY:
			return (Meta<V,K>) super.assignValue(sender, N, event);
		case XX:
			return (Meta<V,K>) super.updateValue(sender, N, event);
		default:
			return (Meta<V,K>) super.putValue(sender, N, event);
		}
	}

	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.Metatext#setFrom(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public void setTo(MassListener sender, Mass<K> event, Mass<V> antievent) {
		switch (getGen()) {
		case XY:
			assignTo(sender, event, antievent);
			return;
		case XX:
			updateTo(sender, event, antievent);
			return;
		default:
			putTo(sender, event, antievent);
			return;
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.Metatext#setTo(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public void setFrom(MassListener sender, Mass<V> event, Mass<K> antievent) {
		switch (getGen()) {
		case XY:
			updateFrom(sender, event, antievent);
			return;
		case XX:
			assignFrom(sender, event, antievent);
			return;
		default:
			putFrom(sender, event, antievent);
			return;
		}
	}
	
    /* (non-Javadoc)
     * @see org.xmlrobot.Hypergenesis#newFlop()
     */
    @Override
    protected Meta<V,K> newFlop() {
    	return new Meta<V,K>(getValue()) {

			/**
			 * -6166984453147308288L
			 */
			private static final long serialVersionUID = -6166984453147308288L;
		};
    }
    /* (non-Javadoc)
     * @see org.xmlrobot.Hypergenesis#newInstant()
     */
    @Override
    protected Meta<K,V> newInstant() {
    	return new Meta<K,V>(getKey()){

			/**
			 * -6517820120972956318L
			 */
			private static final long serialVersionUID = -6517820120972956318L;
    		
    	};
    }
	/**
	 * @param N position
	 */
	protected synchronized void decrease(int N) {
		// decrease to array
        System.arraycopy(toArray(), N + 1, toArray(), N, span().get() - N - 1);
		// update to array
        toArray()[span().decrementAndGet()] = null; // clean to let SC execute its innate ability
	}
    /**
     * Grows to array.
     * @param N the minimum growth to grow
     */
    protected synchronized void increase(int N) {
        if (toArray().length == 0) {
            N = Math.max(DEFAULT_SPAN, N);
        }
        // overflow-conscious code
        if (N - toArray().length > 0){
        	// overflow-conscious code
            int oldGrowth = toArray().length;
            int newGrowth = oldGrowth + (oldGrowth >> 1);
            if (newGrowth - N < 0)
                newGrowth = N;
            if (newGrowth - MAX_ARRAY_SIZE > 0)
                newGrowth = hugeCapacity(N);
            // minGrow is usually close to depth, so this is a triumph:
            toArray(Arrays.copyOf(toArray(), newGrowth));
            fromArray(Arrays.copyOf(fromArray(), newGrowth));
        }
    }
	/**
	 * @param N
	 */
	protected synchronized void increaseFirst(int N) {
		increase(N);
		// copy increased from array
		System.arraycopy(toArray(), 0, toArray(), 1, span().get());
		// copy increased to array
		System.arraycopy(fromArray(), 0, fromArray(), 1, span().get());
	}
    /**
     * Cleans array
     */
    protected synchronized void clean() {
        // clear to let SC do its innate ability
        for (int i = 0; i < span().get(); i++){
        	fromArray()[i] = null;
        	toArray()[i] = null;
        }	
        // restart size
        span().set(0);
    }
}