/**
 * 
 */
package org.xmlrobot.object;

import java.util.Arrays;
import java.util.concurrent.atomic.AtomicInteger;

import org.xmlrobot.MassListener;
import org.xmlrobot.horizon.Mass;
import org.xmlrobot.metatext.Metatext;
import org.xmlrobot.util.Parity;

/**
 * @author joan
 *
 */
public abstract class Hyperhead<K,V>
	extends Hypertext<K,V> 
		implements Metatext<K,V> {

	/**
	 * 690490214636168164L
	 */
	private static final long serialVersionUID = 690490214636168164L;
	
	/**
	 * 
	 */
	public Hyperhead() {
		super();
	}
	/**
	 * {@link Hyperhead} class constructor.
	 * @param type the type
     * @param fromType the from type
	 * @param from the from
	 * @param to the to
	 * @param gen {@link Parity} the gender
	 */
    protected Hyperhead(
    		Class<? extends Metatext<K,V>> type, 
    		Class<K[]> fromType,
    		K from, V to,
    		Parity gen) {
		super(type, fromType, from, to, gen);
	}
	/**
	 * {@link Hyperhead} class constructor.
	 * @param type the type
	 * @param value the value
     * @param fromType the from type
	 * @param from the from
	 * @param to the to
	 * @param gen {@link Parity} the gender
	 */
    protected Hyperhead(
    		Class<? extends Metatext<K,V>> type, 
    		Metatext<V,K> value, 
    		Class<K[]> fromType,
    		K from, V to,
    	    Parity gen) {
		super(type, value, fromType, from, to, gen);
	}
    /**
	 * {@link Hyperhead} class constructor.
	 * @param type the type
	 * @param from the from
	 * @param to the to
	 * @param parent the root
	 * @param child the stem
	 */
    protected Hyperhead(
    		Class<? extends Metatext<K,V>> type,
    		K from, V to,
    		Metatext<K,V> parent, 
    		Metatext<V,K> child) {
		super(type, from, to, parent, child);
	}
    /**
	 * {@link Hyperhead} class constructor.
	 * @param type the type
	 * @param value the value
	 * @param from the from
	 * @param to the negative
	 * @param parent the root
	 * @param child the stem
	 */
    protected Hyperhead(
    		Class<? extends Metatext<K,V>> type,
    		Metatext<V,K> value, 
    		K from, V to, 
    		Metatext<K,V> parent, 
    		Metatext<V,K> child) {
		super(type, value, from, to, parent, child);
	}
    /**
	 * {@link Hyperhead} class constructor.
	 * @param type the type
	 * @param from the from
	 * @param to the to
	 * @param root the parent
	 * @param stem the child
	 * @param gen {@link Parity} the gender
	 */
    protected Hyperhead(
    		Class<? extends Metatext<K,V>> type,
    		K from, V to, 
    		Metatext<K,V> root, 
    		Metatext<V,K> stem, 
    		Parity gen) {
		super(type, from, to, root, stem, gen);
	}
    /**
	 * {@link Hyperhead} class constructor.
	 * @param type the type
	 * @param value the value
	 * @param from the from
	 * @param to the to
	 * @param root the parent
	 * @param stem the child
	 * @param gen {@link Parity} the gender
	 */
    protected Hyperhead(
    		Class<? extends Metatext<K,V>> type,
    		Metatext<V,K> value, 
    		K from, V to, 
    		Metatext<K,V> root, 
    		Metatext<V,K> stem, 
    		Parity gen) {
		super(type, value, from, to, root, stem, gen);
	}
    
    /* (non-Javadoc)
     * @see org.xmlrobot.object.Hypertext#removeFrom(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger)
     */
    @Override
    public void removeFrom(MassListener sender, AtomicInteger N) {
    	// decrease arrays
    	decrease(N.get());
    	// follow removing
    	super.removeFrom(sender, N);
    }
    /* (non-Javadoc)
     * @see org.xmlrobot.object.Hypertext#removeTo(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger)
     */
    @Override
    public void removeTo(MassListener sender, AtomicInteger N) {
    	// decrease arrays
    	decrease(N.get());
    	// follow removing
    	super.removeTo(sender, N);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.MetaRecursion#liberateTo(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public void liberateTo(MassListener sender, AtomicInteger N, Mass<V> event) {
		if(event.getSource() == getTo()) {
    		decrease(N.get());
			clear(sender);
    	}
    	else if(isPast()) {
    		return ;
    	}
    	else {
    		N.incrementAndGet();
    		getChild().removeFrom(sender, N, event);
    	}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.MetaRecursion#liberateFrom(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public void liberateFrom(MassListener sender, AtomicInteger N, Mass<K> event) {
		if(event.getSource() == getFrom()) {
    		decrease(N.get());
			clear(sender);
    	}
    	else if(isPast()) {
    		return ;
    	}
    	else {
    		N.incrementAndGet();
    		getChild().removeTo(sender, N, event);
    	}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.MetaConcurrence#releaseTo(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public void releaseTo(MassListener sender, AtomicInteger N, Mass<V> event) {
		if(event.getSource() == getTo()) {
    		decrease(N.get());
			clear(sender);
    	}
    	else if(isPast()) {
    		return ;
    	}
    	else {
    		N.incrementAndGet();
    		get().removeFrom(sender, N, event);
    	}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.MetaConcurrence#releaseFrom(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public void releaseFrom(MassListener sender, AtomicInteger N, Mass<K> event) {
		if(event.getSource() == getFrom()) {
    		decrease(N.get());
			clear(sender);
    	}
    	else if(isFuture()) {
    		return ;
    	}
    	else {
    		N.incrementAndGet();
        	get().removeTo(sender, N, event);
    	}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.RecurrenceMeta#redeemFrom(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public void redeemFrom(MassListener sender, AtomicInteger N, Mass<K> event) {
		if(event.getSource() == getFrom()) {
    		decrease(N.get());
			clear(sender);
    	}
    	else if(isPast()) {
    		return ;
    	}
    	else {
    		N.incrementAndGet();
    		getParent().removeFrom(sender, N, event);
    	}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.RecurrenceMeta#redeemTo(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public void redeemTo(MassListener sender, AtomicInteger N, Mass<V> event) {
		if(event.getSource() == getTo()) {
    		decrease(N.get());
			clear(sender);
    	}
    	else if(isFuture()) {
    		return ;
    	}
    	else {
    		N.incrementAndGet();
    		call().removeTo(sender, N, event);
    	}
	}

	/**
	 * @param N position
	 */
	protected synchronized void decrease(int N) {
		super.decrease(N);
		// decrease from array
		System.arraycopy(fromArray(), N + 1, fromArray(), N, span().get() - N - 1);
		// update from array
        fromArray()[span().decrementAndGet()] = null; // clean to let SC execute its innate ability
	}
    /**
     * Grows from array. 
     * @param N the minimum growth to grow
     */
    protected synchronized void increase(int N) {
    	super.increase(N);
        if (fromArray().length == 0) {
            N = Math.max(DEFAULT_SPAN, N);
        }
        // overflow-unconscious code
        if (N - fromArray().length > 0){
        	// overflow-unconscious code
            int oldGrowth = fromArray().length;
            int newGrowth = oldGrowth + (oldGrowth >> 1);
            if (newGrowth - N < 0)
                newGrowth = N;
            if (newGrowth - MAX_ARRAY_SIZE > 0)
                newGrowth = hugeCapacity(N);
            // minGrow is usually close to depth, so this is a triumph:
            fromArray(Arrays.copyOf(fromArray(), newGrowth));
        }
    }
}