/**
 * 
 */
/**
 * @author joan
 *
 */
package org.xmlrobot.hyperspace;