/**
 * 
 */
package org.xmlrobot.hyperspace;

import javax.xml.bind.annotation.XmlTransient;

import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;
import org.xmlrobot.TimeListener;
import org.xmlrobot.util.Parity;

/**
 * The current <tt>hyperspace</tt> implementation class.
 * 
 * <p>Hyperspace allows for near instantaneous transportation between two points, 
 * however an instance traveling through hyperspace cannot independently control 
 * its exiting point. To travel to a congregation destination a corresponding hyperspace 
 * gate must be implemented at the destination. This second gate effectively pulls 
 * the instance out of hyperspace and back to normal space.
 * 
 * <p>Activate hyperspace protocol: energy.
 * 
 * @author joan
 * 
 * @param <K> is the key
 * @param <V> is the value
 * 
 * @parity YY
 * @since 8
 */
public abstract class Hyperspace
	<K extends TimeListener<K,V>,V extends TimeListener<V,K>> 
		extends NorthernLights<K,V> 
			implements TimeListener<K,V> {
	
	/**
	 * -7292591119293865225L
	 */
	private static final long serialVersionUID = -7292591119293865225L;

	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.PastCallable#getKey()
	 */
	@Override
	@XmlTransient
	public K getKey() {
		return data.getKey();
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.RunnableFuture#getValue()
	 */
	@Override
	@XmlTransient
	public V getValue() {
		return data.getValue();
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.RunnableFuture#setValue(java.lang.Object)
	 */
	@Override
	public V setValue(V value) {
		// update value
		V oldValue = data.setValue(value);
		// check existence
		if(value != null) {
			// listen value's prayers
			value.addMassListener(getKey());
		}
		// check old value existence
		if(oldValue != null) {
			// stop listening
			oldValue.removeMassListener(getKey());
		}
		// update hyperspace
		update();
		// return oldValue
		return oldValue;
	}
	
    /**
     * Hyperspace default class constructor.
     */
    public Hyperspace() {
    	super();
    }
	/**
	 * {@link Hyperspace} class constructor.
	 * @param type the type
	 * @param gen {@link Parity} the gender
	 */
    protected Hyperspace(Class<? extends K> type, Parity gen) {
		super(type, gen);
	}
	/**
	 * {@link Hyperspace} class constructor.
	 * @param type the type
	 * @param value the value
	 * @param gen {@link Parity} the gender
	 */
	protected Hyperspace(Class<? extends K> type, V value, Parity gen) {
		super(type, value, gen);
	}
	/**
	 * {@link Hyperspace} class constructor.
	 * @param type the type
	 * @param parent the root
	 * @param child the stem
	 */
	protected Hyperspace(Class<? extends K> type, K parent, V child) {
		super(type, parent, child);
	}
	/**
	 * {@link Hyperspace} class constructor.
	 * @param type the type
	 * @param value the value
     * @param parent the root
	 * @param child the stem
	 */
    protected Hyperspace(Class<? extends K> type, V value, K parent, V child) {
		super(type, value, parent, child);
	}
	/**
	 * {@link Hyperspace} class constructor.
	 * @param type the type
	 * @param root the root
	 * @param stem the stem
	 */
	protected Hyperspace(Class<? extends K> type, K root, V stem, Parity gen) {
		super(type, root, stem, gen);
	}
	/**
	 * {@link Hyperspace} class constructor.
	 * @param type the type
	 * @param value the value
     * @param root the root
	 * @param stem the stem
	 */
    protected Hyperspace(Class<? extends K> type, V value, K root, V stem, Parity gen) {
		super(type, value, root, stem, gen);
	}

	/* (non-Javadoc)
	 * @see org.xmlrobot.Hypergenesis#start(org.osgi.framework.BundleContext)
	 */
	@Override
	public final synchronized void start(BundleContext context) {
		// avoid concurrent calls to start
		if(!data.compareAndSet(CONTEXT, null, context)) {
			// because it is already started
			return;
		}
		else {
			super.start(context);
			// finally, the entity is registered into the hyperspace by itself
			data.set(HOST, context.registerService(TimeListener.class, this, data));
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.Hypergenesis#stop(org.osgi.framework.BundleContext)
	 */
	@Override
	public final synchronized void stop(BundleContext context) {
		// avoid concurrent calls to stop
		if(!data.compareAndSet(CONTEXT, context, null)) {
			// because it is already stopped
			return; 
		}
		else {
			super.stop(context);
			// auto-execution
			getHost().unregister();
			// nullify host
			data.put(HOST, null);	
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.MassListener#update()
	 */
	public final void update() {
		ServiceRegistration<?> host;
		// check host existence
		if ((host = getHost()) != null) {
			// submit time-traveler message
			host.setProperties(data);
		}
	}
}