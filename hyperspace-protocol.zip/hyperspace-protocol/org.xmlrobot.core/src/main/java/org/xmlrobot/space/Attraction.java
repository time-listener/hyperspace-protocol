/**
 * 
 */
package org.xmlrobot.space;

import org.xmlrobot.MassListener;
import org.xmlrobot.TimeListener;
import org.xmlrobot.horizon.Mass;
import org.xmlrobot.positron.Positron;
import org.xmlrobot.util.Imperative;
import org.xmlrobot.util.Parity;

/**
 * @author joan
 *
 */
public abstract class Attraction
	<K extends TimeListener<? super K,? super V>,
	 V extends TimeListener<? super V,? super K>> 
		extends Compression<K,V>
			implements Positron<K,V> {

	/**
	 * -1989484839105502373L
	 */
	private static final long serialVersionUID = -1989484839105502373L;

    /**
     * {@link Attraction} default class constructor.
     */
    public Attraction() {
    	super();
    }
    /**
	 * {@link Attraction} class constructor.
	 * @param type the type
	 * @param positive the positive
	 * @param negative the negative
	 * @param gen {@link Parity} the gender
	 */
    protected Attraction(
    		Class<? extends Positron<K,V>> type, 
    		K positive, V negative, Parity gen) {
		super(type, positive, negative, gen);
	}
    /**
	 * {@link Attraction} class constructor.
	 * @param type the type
	 * @param value the value
	 * @param positive the positive
	 * @param negative the negative
	 * @param gen {@link Parity} the gender
	 */
    protected Attraction(
    		Class<? extends Positron<K,V>> type, 
    	    Positron<V,K> value, 
    		K positive, V negative, Parity gen) {
		super(type, value, positive, negative, gen);
	}
    /**
	 * {@link Attraction} class constructor.
	 * @param type the type
	 * @param positive the positive
	 * @param negative the negative
	 * @param parent the parent
	 * @param child the child
	 */
    protected Attraction(
    		Class<? extends Positron<K,V>> type, 
    		K positive, V negative, 
    		Positron<K,V> parent, Positron<V,K> child) {
		super(type, positive, negative, parent, child);
	}
    /**
	 * {@link Attraction} class constructor.
	 * @param type the type
	 * @param value the value
	 * @param positive the positive
	 * @param negative the negative
	 * @param parent the parent
	 * @param child the child
	 */
    protected Attraction(
    		Class<? extends Positron<K,V>> type, 
    	    Positron<V,K> value, 
    		K positive, V negative, 
    		Positron<K,V> parent, Positron<V,K> child) {
		super(type, value, positive, negative, parent, child);
	}
    /**
	 * {@link Attraction} class constructor.
	 * @param type the type
	 * @param positive the positive
	 * @param negative the negative
	 * @param root the root
	 * @param stem the stem
	 * @param gen {@link Parity} the gender
	 */
    protected Attraction(
    		Class<? extends Positron<K,V>> type, 
    		K positive, V negative, 
    		Positron<K,V> parent, Positron<V, K> child, Parity gen) {
		super(type, positive, negative, parent, child, gen);
	}
    /**
	 * {@link Attraction} class constructor.
	 * @param type the type
	 * @param value the value
	 * @param positive the positive
	 * @param negative the negative
	 * @param root the root
	 * @param stem the stem
	 * @param gen {@link Parity} the gender
	 */
    protected Attraction(
    		Class<? extends Positron<K,V>> type, 
    		Positron<V,K> value, K positive, V negative,
    		Positron<K,V> parent, Positron<V,K> child, Parity gen) {
		super(type, value, positive, negative, parent, child, gen);
	}
    
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.RecurrenceMass#hasPositive(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public boolean hasPositive(MassListener sender, Mass<K> event) {
		// check contained
		if (event.getSource() == getPositive()) {
			return true;
		}
		else if (isPast()) {
			return false;
		}
		else return getParent().hasPositive(root(), event);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.RecurrenceMass#hasNegative(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass)
	 */
	@Override
    public boolean hasNegative(MassListener sender, Mass<V> event) {
		// check contained
		if (event.getSource() == getNegative()) {
			return true;
		}
		else if (isFuture()) {
			return false;
		}
		else return call().hasNegative(root(), event);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassConcurrence#holdsNegative(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public boolean holdsNegative(MassListener sender, Mass<V> event) {
		// check contained
		if (event.getSource() == getNegative()) {
			return true;
		}
		else if (isFuture()) {
			return false;
		} 
		else return get().containsPositive(sender, event);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassConcurrence#holdsPositive(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public boolean holdsPositive(MassListener sender, Mass<K> event) {
		// check contained
		if (event.getSource() == getPositive()) {
			return true;
		}
		else if (isFuture()) {
			return false;
		} 
		else return get().containsNegative(sender, event);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassRecursion#belongsPositive(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public boolean belongsPositive(MassListener sender, Mass<K> event) {
		// check contained
		if (event.getSource() == getPositive()) {
			return true;
		}
		else if (isPast()) {
			return false;
		}
		else return getChild().belongsNegative(root(), event);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassRecursion#belongsNegative(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass)
	 */
	@Override
    public boolean belongsNegative(MassListener sender, Mass<V> event) {
		// check contained
		if (event.getSource() == getNegative()) {
			return true;
		} 
		else if (isPast()) {
			return false;
		} 
		else return getChild().belongsPositive(root(), event);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassConcurrence#fromEachPositive(org.xmlrobot.MassListener, org.xmlrobot.util.Imperative)
	 */
	@Override
    public void fromEachPositive(MassListener sender, Imperative<K,V> event) {
    	// accept concurrently to the last child of evolution
		event.accept(getPositive(), getNegative());
		// check future
		if(isFuture()) {
			return;
		}
		else {
	        // concurrent propagation
	        get().forEachNegative(root(), event);
		}
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassConcurrence#fromEachNegative(org.xmlrobot.MassListener, org.xmlrobot.util.Imperative)
	 */
	@Override
    public void fromEachNegative(MassListener sender, Imperative<V,K> event) {
		// accept concurrently to the last child of evolution
		event.accept(getNegative(), getPositive());
		// check future
		if(isFuture()) {
			return;
		}
		else {
			// concurrent propagation
			get().forEachPositive(root(), event);
		}
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.RecurrenceMass#forEveryPositive(org.xmlrobot.MassListener, org.xmlrobot.util.Imperative)
	 */
	@Override
    public void forEveryPositive(MassListener sender, Imperative<K,V> event) {
    	// accept concurrently to the last child of evolution
		event.accept(getPositive(), getNegative());
		// check future
		if(isPast()) {
			return;
		}
		else {
	    	// spread recurrently
	        getChild().forEachNegative(root(), event);
		}
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.RecurrenceMass#forEveryNegative(org.xmlrobot.MassListener, org.xmlrobot.util.Imperative)
	 */
	@Override
    public void forEveryNegative(MassListener sender, Imperative<V,K> event) {
		// accept concurrently to the last child of evolution
		event.accept(getNegative(), getPositive());
		// check future
		if(isPast()) {
			return;
		}
		else {
			// concurrent propagation
	        getChild().forEachPositive(root(), event);
		}
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassRecursion#forAllPositive(org.xmlrobot.MassListener, org.xmlrobot.util.Imperative)
	 */
	@Override
    public void forAllPositive(MassListener sender, Imperative<K,V> event) {
    	// accept concurrently to the last child of evolution
		event.accept(getPositive(), getNegative());
		// check future
		if(isPast()) {
			return;
		}
		else {
	    	// recurrent diffusion
	        getParent().forEachPositive(root(), event);
		}
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassRecursion#forAllNegative(org.xmlrobot.MassListener, org.xmlrobot.util.Imperative)
	 */
	@Override
    public void forAllNegative(MassListener sender, Imperative<V,K> event) {
		// accept concurrently to the last child of evolution
		event.accept(getNegative(), getPositive());
		// check future
		if(isFuture()) {
			return;
		}
		else {
			// recurrent propagation
			call().forEachNegative(root(), event);
		}
    }
}
