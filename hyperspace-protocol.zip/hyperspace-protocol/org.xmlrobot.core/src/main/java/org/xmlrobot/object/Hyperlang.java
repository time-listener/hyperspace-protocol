/**
 * 
 */
package org.xmlrobot.object;

import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;

import org.xmlrobot.MassListener;
import org.xmlrobot.metatext.Metatext;
import org.xmlrobot.util.Congregation;
import org.xmlrobot.util.Parity;

/**
 * @author joan
 *
 * @param <K> is the key
 * @param <V> is the value
 */
public abstract class Hyperlang<K,V>
	extends Hyperhead<K,V>
		implements Metatext<K,V> {

	/**
	 * -682743345758969605L
	 */
	private static final long serialVersionUID = -682743345758969605L;

	/**
	 * 
	 */
	public Hyperlang() {
		super();
	}
	/**
	 * {@link Hyperlang} class constructor.
	 * @param type the type
     * @param fromType the from type
	 * @param from the from
	 * @param to the to
	 * @param gen {@link Parity} the gender
	 */
    protected Hyperlang(
    		Class<? extends Metatext<K,V>> type, 
    		Class<K[]> fromType,
    		K from, V to,
    		Parity gen) {
		super(type, fromType, from, to, gen);
	}
	/**
	 * {@link Hyperlang} class constructor.
	 * @param type the type
	 * @param value the value
     * @param fromType the from type
	 * @param from the from
	 * @param to the to
	 * @param gen {@link Parity} the gender
	 */
    protected Hyperlang(
    		Class<? extends Metatext<K,V>> type, 
    		Metatext<V,K> value, 
    		Class<K[]> fromType,
    		K from, V to,
    	    Parity gen) {
		super(type, value, fromType, from, to, gen);
	}
    /**
	 * {@link Hyperlang} class constructor.
	 * @param type the type
	 * @param from the from
	 * @param to the to
	 * @param parent the root
	 * @param child the stem
	 */
    protected Hyperlang(
    		Class<? extends Metatext<K,V>> type,
    		K from, V to, 
    		Metatext<K,V> parent, 
    		Metatext<V,K> child) {
		super(type, from, to, parent, child);
	}
    /**
	 * {@link Hyperlang} class constructor.
	 * @param type the type
	 * @param value the value
	 * @param from the from
	 * @param to the negative
	 * @param parent the root
	 * @param child the stem
	 */
    protected Hyperlang(
    		Class<? extends Metatext<K,V>> type,
    		Metatext<V,K> value, 
    		K from, V to, 
    		Metatext<K,V> parent, 
    		Metatext<V,K> child) {
		super(type, value, from, to, parent, child);
	}
    /**
	 * {@link Hyperlang} class constructor.
	 * @param type the type
	 * @param from the from
	 * @param to the to
	 * @param root the parent
	 * @param stem the child
	 * @param gen {@link Parity} the gender
	 */
    protected Hyperlang(
    		Class<? extends Metatext<K,V>> type,
    		K from, V to, 
    		Metatext<K,V> root,
    		Metatext<V,K> stem,
    		Parity gen) {
		super(type, from, to, root, stem, gen);
	}
    /**
	 * {@link Hyperlang} class constructor.
	 * @param type the type
	 * @param value the value
	 * @param from the from
	 * @param to the to
	 * @param root the parent
	 * @param stem the child
	 * @param gen {@link Parity} the gender
	 */
    protected Hyperlang(
    		Class<? extends Metatext<K,V>> type,
    		Metatext<V,K> value,
    		K from, V to,
    		Metatext<K,V> root, 
    		Metatext<V,K> stem,
    		Parity gen) {
		super(type, value, from, to, root, stem, gen);
	}

	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.Metatext#excerpt(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger, java.util.concurrent.atomic.AtomicInteger)
	 */
	@Override
	public Congregation<K> excerpt(MassListener sender, AtomicInteger beginIndex, AtomicInteger endIndex) {		
        // create new congregation
		return excerptFrom(sender, beginIndex, endIndex, 
				new Congregation<K>(new ArrayList<K>()) {
					/**
					 * 7327871724932040856Ls
					 */
					private static final long serialVersionUID = 7327871724932040856L;
		});
	}
	
	/* (non-Javadoc)
	 * @see org.xmlrobot.object.Hypertext#excerptFrom(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger, java.util.concurrent.atomic.AtomicInteger, org.xmlrobot.util.Congregation)
	 */
	@Override
	public Congregation<K> excerptFrom(MassListener sender, AtomicInteger beginIndex, AtomicInteger endIndex, Congregation<K> event) {
		// create natural counter
		AtomicInteger N = new AtomicInteger(0);
		// commute by parity
		switch (getGen()) {
		case XX:
			concurrence(sender, N);
			break;
		default:
			recurrence(sender, N);
			break;
		}
		// sequence range
		if (beginIndex.get() < 0) {
            throw new StringIndexOutOfBoundsException(beginIndex.get());
        }
        if (endIndex.get() > N.get()) {
            throw new StringIndexOutOfBoundsException(endIndex.get());
        }
        int subLen = endIndex.get() - beginIndex.get();
        if (subLen < 0) {
        	throw new StringIndexOutOfBoundsException(subLen);
        }
		return super.excerptFrom(sender, beginIndex, endIndex, event);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.object.Hypertext#excerptTo(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger, java.util.concurrent.atomic.AtomicInteger, org.xmlrobot.util.Congregation)
	 */
	@Override
	public Congregation<V> excerptTo(MassListener sender, AtomicInteger beginIndex, AtomicInteger endIndex, Congregation<V> event) {
		// create natural counter
		AtomicInteger N = new AtomicInteger(0);
		// commute by parity
		switch (getGen()) {
		case XX:
			recurrence(sender, N);
			break;
		default:
			concurrence(sender, N);
			break;
		}
		
		if (beginIndex.get() < 0) {
            throw new StringIndexOutOfBoundsException(beginIndex.get());
        }
        if (endIndex.get() > concurrence(sender, new AtomicInteger(0)).get()) {
            throw new StringIndexOutOfBoundsException(endIndex.get());
        }
        int subLen = endIndex.get() - beginIndex.get();
        if (subLen < 0) {
        	throw new StringIndexOutOfBoundsException(subLen);
        }
		return super.excerptTo(sender, beginIndex, endIndex, event);
	}
	
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.MetaRunnable#subsequenceFrom(org.xmlrobot.genesis.TimeListener, int, int, org.xmlrobot.horizon.Meta)
	 */
	@Override
	public Congregation<V> subsequenceTo(MassListener sender, AtomicInteger beginIndex, AtomicInteger endIndex, Congregation<V> event) {
        // return builder or call recursion
		// check start index
		if (beginIndex.get() <= 0) {
			// append to from event
			event.add(getTo());
		}
		// check stop index
		if (endIndex.get() == 0) {
			return event;
		}
		// decrement counters
		beginIndex.decrementAndGet();
		endIndex.decrementAndGet();
		
		if (isFuture()) {
			return event;
		}
		else return get().excerptFrom(sender, beginIndex, endIndex, event) ;
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.MetaConcurrence#subsequenceFrom(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger, java.util.concurrent.atomic.AtomicInteger, org.xmlrobot.util.Congregation)
	 */
	@Override
	public Congregation<K> subsequenceFrom(MassListener sender, AtomicInteger beginIndex, AtomicInteger endIndex, Congregation<K> event) {
		if (beginIndex.get() <= 0) {
            // append to from array
			event.add(getFrom());
        }
		// check stop index
		if (endIndex.get() == 0) {
			return event;
		}
		// decrement counters
		beginIndex.decrementAndGet();
		endIndex.decrementAndGet();
		
		if (isFuture()) {
			return event;
		}
		else return get().excerptTo(sender, beginIndex, endIndex, event) ;
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.PastMeta#subchain(org.xmlrobot.genesis.TimeListener, int, int, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public Congregation<K> subchainFrom(MassListener sender, AtomicInteger beginIndex, AtomicInteger endIndex, Congregation<K> event) {
        // return builder or call recursion
		if (beginIndex.get() <= 0) {
            // append to from array
			event.add(getFrom());
        }
		// check stop index
		if (endIndex.get() == 0) {
			return event;
		}
		// decrement counters
		beginIndex.decrementAndGet();
		endIndex.decrementAndGet();
		
		if (isPast()) {
			return event;
		}
		else return getParent().excerptFrom(sender, beginIndex, endIndex, event);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.CallableMeta#subchainTo(org.xmlrobot.genesis.TimeListener, int, int, org.xmlrobot.horizon.Meta)
	 */
	@Override
	public Congregation<V> subchainTo(MassListener sender, AtomicInteger beginIndex, AtomicInteger endIndex, Congregation<V> event) {
		// check start index
		if (beginIndex.get() <= 0) {
			// append to from event
			event.add(getTo());
		}
		// check stop index
		if (endIndex.get() == 0) {
			return event;
		}
		// decrement counters
		beginIndex.decrementAndGet();
		endIndex.decrementAndGet();

		if (isFuture()) {
			return event;
		} 
		else return call().excerptTo(sender, beginIndex, endIndex, event);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.PastMeta#subchain(org.xmlrobot.genesis.TimeListener, int, int, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public Congregation<K> substringFrom(MassListener sender, AtomicInteger beginIndex, AtomicInteger endIndex, Congregation<K> event) {
        // return builder or call recursion
        if (beginIndex.get() <= 0) {
            // append to from array
			event.add(getFrom());
        }
		// check stop index
		if (endIndex.get() == 0) {
			return event;
		}
		// decrement counters
		beginIndex.decrementAndGet();
		endIndex.decrementAndGet();
		
		if (isPast()) {
			return event;
		}
		else return getChild().excerptTo(sender, beginIndex, endIndex, event) ;
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.CallableMeta#subchainTo(org.xmlrobot.genesis.TimeListener, int, int, org.xmlrobot.horizon.Meta)
	 */
	@Override
	public Congregation<V> substringTo(MassListener sender, AtomicInteger beginIndex, AtomicInteger endIndex, Congregation<V> event) {
        // return builder or call recursion
		// check start index
		if (beginIndex.get() <= 0) {
			// append to from event
			event.add(getTo());
		}
		// check stop index
		if (endIndex.get() == 0) {
			return event;
		}
		// decrement counters
		beginIndex.decrementAndGet();
		endIndex.decrementAndGet();

		if (isPast()) {
			return event;
		} 
		else return getChild().excerptFrom(sender, beginIndex, endIndex, event);
	}	
}
