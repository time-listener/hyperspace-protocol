/**
 * 
 */
/**
 * @author joan
 *
 */
package org.xmlrobot.object;