/**
 * 
 */
package org.xmlrobot.space;

import org.xmlrobot.MassListener;
import org.xmlrobot.TimeListener;
import org.xmlrobot.horizon.Mass;
import org.xmlrobot.positron.Positron;
import org.xmlrobot.util.Parity;
import org.xmlrobot.util.Commandment;

/**
 * @author joan
 *
 */
public abstract class Repulsion
	<K extends TimeListener<? super K,? super V>,
	 V extends TimeListener<? super V,? super K>> 
		extends Dilatation<K,V>
			implements Positron<K,V> {

	/**
	 * 2677857047197236447L
	 */
	private static final long serialVersionUID = 2677857047197236447L;

    /**
     * {@link Repulsion} default class constructor.
     */
    public Repulsion() {
    	super();
    }
    /**
	 * {@link Repulsion} class constructor.
	 * @param type the type
	 * @param key the key
	 * @param value the value
	 * @param gen {@link Parity} the gender
	 */
    protected Repulsion(
    		Class<? extends Positron<K,V>> type, 
    		K key, V value, Parity gen) {
		super(type, key, value, gen);
	}
    /**
	 * {@link Repulsion} class constructor.
	 * @param type the type
	 * @param antitype the antitype
	 * @param key the key
	 * @param value the value
	 * @param gen {@link Parity} the gender
	 */
    protected Repulsion(
    		Class<? extends Positron<K,V>> type, 
    	    Class<? extends Positron<V,K>> antitype, 
    		K key, V value, Parity gen) {
		super(type, antitype, key, value, gen);
	}
    /**
	 * {@link Repulsion} class constructor.
	 * @param type the type
	 * @param key the key
	 * @param value the value
	 * @param parent the parent
	 * @param child the child
	 */
    protected Repulsion(
    		Class<? extends Positron<K,V>> type, 
    		K key, V value, 
    		Positron<K,V> parent,
    		Positron<V,K> child) {
		super(type, key, value, parent, child);
	}
    /**
	 * {@link Repulsion} class constructor.
	 * @param type the type
	 * @param antitype the antitype
	 * @param key the key
	 * @param value the value
	 * @param parent the parent
	 * @param child the child
	 */
    protected Repulsion(
    		Class<? extends Positron<K,V>> type, 
    		Class<? extends Positron<V,K>> antitype, 
    		K key, V value,
    		Positron<K,V> parent, 
    		Positron<V,K> child) {
		super(type, antitype, key, value, parent, child);
	}
    /**
	 * {@link Repulsion} class constructor.
	 * @param type the type
	 * @param key the key
	 * @param value the value
	 * @param root the root
	 * @param stem the stem
	 * @param gen {@link Parity} the gender
	 */
    protected Repulsion(
    		Class<? extends Positron<K,V>> type, 
    		K key, V value, 
    		Positron<K,V> parent,
    		Positron<V,K> child,
    		Parity gen) {
		super(type, key, value, parent, child, gen);
	}
    /**
	 * {@link Repulsion} class constructor.
	 * @param type the type
	 * @param antitype the antitype
	 * @param key the key
	 * @param value the value
	 * @param root the root
	 * @param stem the stem
	 * @param gen {@link Parity} the gender
	 */
    protected Repulsion(
    		Class<? extends Positron<K,V>> type, 
    		Class<? extends Positron<V,K>> antitype, 
    		K key, V value,
    		Positron<K,V> parent, 
    		Positron<V,K> child,
    		Parity gen) {
		super(type, antitype, key, value, parent, child, gen);
	}

	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassRecursion#restorePositive(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass)
	 */
	@Override
    public void restorePositive(MassListener sender, Mass<V> event, Mass<K> oldAntievent, Mass<K> newAntievent) {
		if(event.getSource() == getNegative()) {
			// compare and set positive
    		data.compareAndSet(Positron.POSITIVE, 
    				oldAntievent.getSource(), newAntievent.getSource());
    	}
    	else if(isPast()) {
    		return;
    	}
    	else getChild().replaceNegative(sender, event, oldAntievent, newAntievent);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassRecursion#restoreNegative(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass)
	 */
	@Override
    public void restoreNegative(MassListener sender, Mass<K> event, Mass<V> oldAntievent, Mass<V> newAntievent) {
		// check by positive
		if (event.getSource() == getPositive()) {
			// compare and set negatives
			data.compareAndSet(Positron.NEGATIVE, oldAntievent.getSource(),
					newAntievent.getSource());
		}
		else if (isPast()) {
			return;
		}
		else getChild().replacePositive(sender, event, oldAntievent, newAntievent);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.RecurrenceMass#relocateNegative(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass)
	 */
	@Override
    public void relocateNegative(MassListener sender, Mass<K> event, Mass<V> oldAntievent, Mass<V> newAntievent) {
		// check by positive
		if (event.getSource() == getPositive()) {
			// compare and set negatives
			data.compareAndSet(Positron.NEGATIVE, oldAntievent.getSource(),
					newAntievent.getSource());
		}
		else if (isFuture()) {
			return;
		}
		else call().replaceNegative(sender, event, oldAntievent, newAntievent);;
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.RecurrenceMass#relocatePositive(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass)
	 */
	@Override
    public void relocatePositive(MassListener sender, Mass<V> event, Mass<K> oldAntievent, Mass<K> newAntievent) {
		if(event.getSource() == getNegative()) {
			// compare and set positive
    		data.compareAndSet(Positron.POSITIVE, 
    				oldAntievent.getSource(), newAntievent.getSource());
    	}
    	else if(isPast()) {
    		return;
    	}
    	else getParent().replacePositive(sender, event, oldAntievent, newAntievent);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassConcurrence#reassignNegative(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass)
	 */
	@Override
    public void reassignNegative(MassListener sender, Mass<K> event, Mass<V> oldAntievent, Mass<V> newAntievent) {
		// check by positive
		if (event.getSource() == getPositive()) {
			// compare and set negatives
			data.compareAndSet(Positron.NEGATIVE, oldAntievent.getSource(),
					newAntievent.getSource());
		} 
		else if (isFuture()) {
			return;
		} 
		else get().replacePositive(sender, event, oldAntievent, newAntievent);;
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassConcurrence#reassignPositive(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass)
	 */
	@Override
    public void reassignPositive(MassListener sender, Mass<V> event, Mass<K> oldAntievent, Mass<K> newAntievent) {
		if(event.getSource() == getNegative()) {
			// compare and set positive
    		data.compareAndSet(Positron.POSITIVE, 
    				oldAntievent.getSource(), newAntievent.getSource());
    	}
    	else if(isFuture()) {
    		return;
    	}
    	else get().replaceNegative(sender, event, oldAntievent, newAntievent);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassRecursion#restoreNegative(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass)
	 */
	@Override
    public void restoreNegative(MassListener sender, Mass<K> event, Mass<V> antievent) {
		if(event.getSource() == getPositive()) {
			// update negative
    		data.getAndSet(Positron.NEGATIVE, antievent.getSource());
    	}
    	else if(!isPast()) {
    		return;
    	}
    	else getChild().replacePositive(sender, event, antievent);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassRecursion#restorePositive(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass)
	 */
	@Override
    public void restorePositive(MassListener sender, Mass<V> event, Mass<K> antievent) {
		if(event.getSource() == getNegative()) {
			// update negative
    		data.getAndSet(Positron.POSITIVE, antievent.getSource());
    	}
    	else if(!isPast()) {
    		return;
    	}
    	else getChild().replaceNegative(sender, event, antievent);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.RecurrenceMass#relocateNegative(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass)
	 */
	@Override
    public void relocateNegative(MassListener sender, Mass<K> event, Mass<V> antievent) {
		if(event.getSource() == getPositive()) {
			// update negative
    		data.getAndSet(Positron.NEGATIVE, antievent.getSource());
    	}
    	else if(!isFuture()) {
    		return;
    	}
    	else call().replaceNegative(sender, event, antievent);;
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.RecurrenceMass#relocatePositive(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass)
	 */
	@Override
    public void relocatePositive(MassListener sender, Mass<V> event, Mass<K> antievent) {
		if(event.getSource() == getNegative()) {
			// update negative
    		data.getAndSet(Positron.POSITIVE, antievent.getSource());
    	}
    	else if(!isPast()) {
    		return;
    	}
    	else getParent().replacePositive(sender, event, antievent);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassConcurrence#reassignNegative(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass)
	 */
	@Override
    public void reassignNegative(MassListener sender, Mass<K> event, Mass<V> antievent) {
		if(event.getSource() == getPositive()) {
			// update negative
    		data.getAndSet(Positron.NEGATIVE, antievent.getSource());
    	}
    	else if(!isFuture()) {
    		return;
    	}
    	else get().replacePositive(sender, event, antievent);;
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassConcurrence#reassignPositive(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass)
	 */
	@Override
    public void reassignPositive(MassListener sender, Mass<V> event, Mass<K> antievent) {
		if(event.getSource() == getNegative()) {
			// update negative
    		data.getAndSet(Positron.POSITIVE, antievent.getSource());
    	}
    	else if(!isFuture()) {
    		return;
    	}
    	else get().replaceNegative(sender, event, antievent);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassRecursion#restoreAllPositives(org.xmlrobot.MassListener, org.xmlrobot.util.Commandment)
	 */
	@Override
    public void restoreAllPositives(MassListener sender, Commandment<V,K> event) {
		// obey my commandments
		setPositive(event.apply(getNegative(), getPositive()));
		// check time
		if(!isPast()) {
			// request recursion
			getChild().replaceAllNegatives(sender, event);	
		}
		else return;
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassRecursion#restoreAllNegatives(org.xmlrobot.MassListener, org.xmlrobot.util.Commandment)
	 */
	@Override
	public void restoreAllNegatives(MassListener sender, Commandment<K,V> event) {
		// obey my commandments
		setNegative(event.apply(getPositive(), getNegative()));
		// check time
		if(!isPast()) {
			// request recursion
			getChild().replaceAllPositives(sender, event);	
		}
		else return;
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.RecurrenceMass#relocateAllPositives(org.xmlrobot.MassListener, org.xmlrobot.util.Commandment)
	 */
	@Override
    public void relocateAllPositives(MassListener sender, Commandment<V,K> event) {
		// apply unification function
		setPositive(event.apply(getNegative(), getPositive()));
		// check time
		if(!isPast()) {
			// call recurrence
			getParent().replaceAllPositives(sender, event);	
		}
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.RecurrenceMass#relocateAllNegatives(org.xmlrobot.MassListener, org.xmlrobot.util.Commandment)
	 */
	@Override
	public void relocateAllNegatives(MassListener sender, Commandment<K,V> event) {
		// obey commandment
		setNegative(event.apply(getPositive(), getNegative()));
		// check time
		if(!isFuture()) {
			// call recurrence
			call().replaceAllNegatives(sender, event);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassConcurrence#reassignAllNegatives(org.xmlrobot.MassListener, org.xmlrobot.util.Commandment)
	 */
	@Override
	public void reassignAllNegatives(MassListener sender, Commandment<K,V> event) {
		// obey commandment
		setNegative(event.apply(getPositive(), getNegative()));
		// check time
		if(!isFuture()) {
			// get concurrence
			get().replaceAllPositives(sender, event);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassConcurrence#reassignAllPositives(org.xmlrobot.MassListener, org.xmlrobot.util.Commandment)
	 */
	@Override
    public void reassignAllPositives(MassListener sender, Commandment<V,K> event) {
		// apply unification function
		setPositive(event.apply(getNegative(), getPositive()));
		// check time
		if(!isFuture()) {
			// get concurrence
			get().replaceAllNegatives(sender, event);
		}
    }
}