/**
 * 
 */
package org.xmlrobot.object;

import java.util.concurrent.atomic.AtomicInteger;

import org.xmlrobot.MassListener;
import org.xmlrobot.horizon.Mass;
import org.xmlrobot.horizon.Meta;
import org.xmlrobot.metatext.Metatext;
import org.xmlrobot.util.Parity;

/**
 * @author joan
 *
 */
public abstract class Hyperbody<K,V> 
	extends Hypermath<K,V> 
		implements Metatext<K,V> {

	/**
	 * -2813944274475982273L
	 */
	private static final long serialVersionUID = -2813944274475982273L;
	
	/**
	 * {@link Hyperbody} default class constructor.
	 */
	public Hyperbody() {
		super();
	}
	/**
	 * {@link Hyperbody} class constructor.
	 * @param type the type
     * @param fromType the from type
	 * @param from the from
	 * @param to the to
	 * @param gen {@link Parity} the gender
	 */
    protected Hyperbody(
    		Class<? extends Metatext<K,V>> type, 
    		Class<K[]> fromType,
    		K from, V to,
    		Parity gen) {
		super(type, fromType, from, to, gen);
	}
	/**
	 * {@link Hyperbody} class constructor.
	 * @param type the type
	 * @param antitype the antitype
     * @param fromType the from type
	 * @param from the from
	 * @param to the to
	 * @param gen {@link Parity} the gender
	 */
    protected Hyperbody(
    		Class<? extends Metatext<K,V>> type, 
    	    Class<? extends Metatext<V,K>> antitype,
    		Class<K[]> fromType,
    		K from, V to,
    	    Parity gen) {
		super(type, antitype, fromType, from, to, gen);
	}
    /**
	 * {@link Hyperbody} class constructor.
	 * @param type the type
	 * @param from the from
	 * @param to the to
	 * @param parent the root
	 * @param child the stem
	 */
    protected Hyperbody(
    		Class<? extends Metatext<K,V>> type,
    		K from, V to,
    		Metatext<K,V> parent,
    		Metatext<V,K> child) {
		super(type, from, to, parent, child);
	}
    /**
	 * {@link Hyperbody} class constructor.
	 * @param type the type
	 * @param antitype the antitype
	 * @param from the from
	 * @param to the negative
	 * @param parent the root
	 * @param child the stem
	 */
    protected Hyperbody(
    		Class<? extends Metatext<K,V>> type,
    	   	Class<? extends Metatext<V,K>> antitype, 
    		K from, V to,
    		Metatext<K,V> parent,
    		Metatext<V,K> child) {
		super(type, antitype, from, to, parent, child);
	}
    /**
	 * {@link Hyperbody} class constructor.
	 * @param type the type
	 * @param from the from
	 * @param to the to
	 * @param root the parent
	 * @param stem the child
	 * @param gen {@link Parity} the gender
	 */
    protected Hyperbody(
    		Class<? extends Metatext<K,V>> type,
    		K from, V to,
    		Metatext<K,V> root,
    		Metatext<V,K> stem,
    		Parity gen) {
		super(type, from, to, root, stem, gen);
	}
    /**
	 * {@link Hyperbody} class constructor.
	 * @param type the type
	 * @param antitype the antitype
	 * @param from the from
	 * @param to the to
	 * @param root the parent
	 * @param stem the child
	 * @param gen {@link Parity} the gender
	 */
    protected Hyperbody(
    		Class<? extends Metatext<K,V>> type,
    	    Class<? extends Metatext<V,K>> antitype,
    		K from, V to,
    		Metatext<K,V> root,
    		Metatext<V,K> stem,
    		Parity gen) {
		super(type, antitype, from, to, root, stem, gen);
	}
    
	/* (non-Javadoc)
	 * @see org.xmlrobot.object.Hypertext#setTo(org.xmlrobot.MassListener, org.xmlrobot.horizon.Meta)
	 */
	@Override
	public void setTo(MassListener sender, Meta<V,K> event) {
		super.setTo(sender, event);
		switch (getGen()) {
		case XX:
			// insert to on the head of the array
			increaseFirst(span().get() + 1);
			// insert to on the head of the array
			toArray()[0] = event.getFrom();
			// insert from on the head of the array
			fromArray()[0] = event.getTo();
			// grow from +1
			span().incrementAndGet();
			break;
		default:
			// ensure internal array capacity
	        increase(span().incrementAndGet());
	        // store from to array
	    	toArray()[span().get()] = event.getFrom();
	        // store from to from array
	    	fromArray()[span().get()] = event.getTo();
			break;
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.object.Hypertext#setFrom(org.xmlrobot.MassListener, org.xmlrobot.horizon.Meta)
	 */
	@Override
	public void setFrom(MassListener sender, Meta<K,V> event) {
		super.setFrom(sender, event);
		switch (getGen()) {
		case XX:
			// ensure internal array capacity
	        increase(span().incrementAndGet());
	        // store from to array
	    	toArray()[span().get()] = event.getTo();
	        // store from to from array
	    	fromArray()[span().get()] = event.getFrom();
			break;
		default:
			// insert to on the head of the array
			increaseFirst(span().get() + 1);
			// insert to on the head of the array
			toArray()[0] = event.getTo();
			// insert from on the head of the array
			fromArray()[0] = event.getFrom();
			// grow from +1
			span().incrementAndGet();
			break;
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.object.Hypertext#setFrom(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger, org.xmlrobot.horizon.Meta)
	 */
	@Override
	public Meta<K,V> setFrom(MassListener sender, AtomicInteger N, Meta<K,V> event) {
		// set from to from array
		fromArray()[N.get()] = event.getFrom();
		// set to from to array
		toArray()[N.get()] = event.getTo();
		// call ancestral recall
		return super.setFrom(sender, N, event);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.object.Hypertext#setTo(org.xmlrobot.MassListener, java.util.concurrent.atomic.AtomicInteger, org.xmlrobot.horizon.Meta)
	 */
	@Override
	public Meta<V,K> setTo(MassListener sender, AtomicInteger N, Meta<V,K> event) {
		// set from to from array
		fromArray()[N.get()] = event.getTo();
		// set to from to array
		toArray()[N.get()] = event.getFrom();
		// call ancestral recall
		return super.setTo(sender, N, event);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.RecurrenceMeta#putFrom(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public void putTo(MassListener sender, Mass<K> event, Mass<V> antievent) {
		// check event existence
		if (event.getSource() == getFrom()) {
			setTo(antievent.getSource());
		} 
		else if (isFuture()) {
			// key is not in the chain: create it
			instance(getAntitype(), getType(), 
					event.getSource(), antievent.getSource(), getValue(), getKey());
		}
		// call recursion
		else call().setTo(sender, event, antievent);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.RecurrenceMeta#putTo(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public void putFrom(MassListener sender, Mass<V> event, Mass<K> antievent) {
		// check event existence
		if (event.getSource() == getTo()) {
			setFrom(antievent.getSource());
		}
		// check future
		else if (isPast()) {
			// key is not in the chain: create it
			instance(getAntitype(), getType(), 
					event.getSource(), antievent.getSource(), getChild(), getParent());
		}
		// call recursion
		else getParent().setFrom(sender, event, antievent);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.MetaRecursion#updateTo(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public void updateFrom(MassListener sender, Mass<V> event, Mass<K> antievent) {
		// check event existence
		if (event.getSource() == getTo()) {
			setFrom(antievent.getSource());
		}
		// check future
		else if (isPast()) {
			// key is not in the chain: create it
			instance(getAntitype(), getType(), 
					event.getSource(), antievent.getSource(), getChild(), getParent());
		}
		// call recursion
		else getChild().setTo(sender, event, antievent);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.MetaRecursion#updateFrom(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public void updateTo(MassListener sender, Mass<K> event, Mass<V> antievent) {
		// check event existence
		if (event.getSource() == getFrom()) {
			setTo(antievent.getSource());
		} 
		else if (isPast()) {
			// key is not in the chain: create it
			instance(getAntitype(), getType(), 
					event.getSource(), antievent.getSource(), getChild(), getParent());
		}
		// call recursion
		else getChild().setFrom(sender, event, antievent);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.MetaConcurrence#assignTo(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public void assignFrom(MassListener sender, Mass<V> event, Mass<K> antievent) {
		// check event existence
		if (event.getSource() == getTo()) {
			setFrom(antievent.getSource());
		}
		// check future
		else if (isFuture()) {
			// key is not in the chain: create it
			instance(getAntitype(), getType(), 
					event.getSource(), antievent.getSource(), getValue(), getKey());
		}
		// call recursion
		else get().setTo(sender, event, antievent);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.MetaConcurrence#assignFrom(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public void assignTo(MassListener sender, Mass<K> event, Mass<V> antievent) {
		// check event existence
		if (event.getSource() == getFrom()) {
			setTo(antievent.getSource());
		} 
		else if (isFuture()) {
			// key is not in the chain: create it
			instance(getAntitype(), getType(), 
					antievent.getSource(), event.getSource(), getValue(), getKey());
		}
		// call recursion
		else get().setFrom(sender, event, antievent);
	}
}