	/**
 * 
 */
package org.xmlrobot.hyperspace;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.concurrent.atomic.AtomicInteger;

import javax.xml.bind.annotation.XmlElement;

import org.xmlrobot.Hypergenesis;
import org.xmlrobot.MassListener;
import org.xmlrobot.TimeListener;
import org.xmlrobot.horizon.Tachyon;
import org.xmlrobot.util.Parity;

/**
 * The unification of everything and nothing.
 * @author joan
 * 
 * @param <K> is the key
 * @param <V> is the value
 * 
 * @parity YY
 * @since 2
 *
 */
public abstract class Unification
	<K extends TimeListener<K,V>,V extends TimeListener<V,K>> 
		extends Hypergenesis<K,V>
			implements TimeListener<K,V> {

	/**
	 * 5574710177408508814L
	 */
	private static final long serialVersionUID = 5574710177408508814L;

	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.Past#getType()
	 */
	@Override
	@XmlElement
	public Class<? extends K> getType() {
		return data.getType();
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.Past#setType(java.lang.Class)
	 */
	@Override
	public void setType(Class<? extends K> value) {
		data.setType(value);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.Future#getAntitype()
	 */
	@Override
	@XmlElement
	public Class<? extends V> getAntitype() {
		return data.getAntitype();
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.Future#setAntitype(java.lang.Class)
	 */
	@Override
	public void setAntitype(Class<? extends V> value) {
		data.setAntitype(value);
	}
	
	/**
     * {@link Unification} default class constructor.
     */
	public Unification() {
		super();
	}
	/**
     * {@link Unification} class constructor.
	 * @param type the type
     * @param gen {@link Parity} the gender
	 */
	protected Unification(Class<? extends K> type, Parity gen) {
		super(type, gen);
	}
 	/**
     * {@link Unification} class constructor.
	 * @param type the type
	 * @param value the value
	 * @param gen {@link Parity} the gender
	 */
	protected Unification(Class<? extends K> type, V value, Parity gen) {
		super(type, value.getType(), value, gen);
		// put past
		set(value);
		// set future
		put(getKey());
	}
	/**
     * {@link Unification} class constructor.
	 * @param type the type
	 * @param parent the parent
	 * @param child the child
	 */
	protected Unification(Class<? extends K> type, K parent, V child) {
		super(type, parent, child);
	}
	/**
	 * @param type
	 * @param value
	 * @param parent
	 * @param child
	 * @param gen
	 */
	protected Unification(Class<? extends K> type, V value, K parent, V child){
		super(type, value.getType(), value, parent, child);
		// put past
		put(parent.call());
		// set future
		set(child.call());
	}
	/**
     * {@link Unification} class constructor.
	 * @param type the type
	 * @param parent the parent
	 * @param child the child
	 */
	protected Unification(Class<? extends K> type, K root, V stem, Parity gen) {
		super(type, root, stem);
	}
	/**
	 * @param type
	 * @param value
	 * @param root
	 * @param stem
	 * @param gen
	 */
	protected Unification(Class<? extends K> type, V value, K root, V stem, Parity gen){
		super(type, value.getType(), value, root, stem);
	}
	
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.MassListener#unify()
	 */
	@Override
	public void unify(MassListener sender) {
		// set value's future
		put(getKey());
		// set future
		set(getValue());
		// set parent
		setParent(getKey());
		// set child
		setChild(getValue());
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#allocateValue(org.xmlrobot.TimeListener, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public synchronized void allocateValue(MassListener source, Tachyon<V,K> event) {
		// commute event
		switch (getGen()) {
		case YY:
			deliverValue(source, event);
			break;
		default:
			orderValue(source, event);
			break;
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#allocateKey(org.xmlrobot.TimeListener, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public synchronized void allocateKey(MassListener source, Tachyon<K,V> event) {
		switch (getGen()) {
		case YY:
			deliverKey(source, event);
			return;
		default:
			orderKey(source, event);
			return;
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#containsKey(org.xmlrobot.MassListener, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
    public boolean containsKey(MassListener sender, Tachyon<K,V> event) {
		switch (getGen()) {
		case XY:
			return holdsKey(sender, event);
		case XX:
			return belongsKey(sender, event);
		default:
			return hasKey(sender, event);
		}
    }
    /* (non-Javadoc)
     * @see org.xmlrobot.TimeListener#containsValue(org.xmlrobot.MassListener, org.xmlrobot.horizon.Tachyon)
     */
    @Override
    public boolean containsValue(MassListener sender, Tachyon<V,K> event) {
    	switch (getGen()) {
		case XY:
			return belongsValue(sender, event);
		case XX:
			return holdsValue(sender, event);
		default:
			return hasValue(sender, event);
		}
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#deliverValue(org.xmlrobot.MassListener, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public synchronized void deliverValue(MassListener sender, Tachyon<V,K> event) {
		// commute by parity
		switch (getGen()) {
		case XY:
			submitValue(sender, event);
			return;
		case XX:
			injectValue(sender, event);
			return;
		default:
			pushValue(sender, event);
			return;
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#deliverKey(org.xmlrobot.MassListener, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public synchronized void deliverKey(MassListener sender, Tachyon<K,V> event) {
		// commute by parity
		switch (getGen()) {
		case XY:
			injectKey(sender, event);
			return;
		case XX:
			submitKey(sender, event);
			return;
		default:
			pushKey(sender, event);
			return;
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#revealValue(org.xmlrobot.TimeListener, java.util.concurrent.atomic.AtomicInteger)
	 */
	@Override
	public Tachyon<V,K> getValue(MassListener sender, AtomicInteger N) {
		switch (getGen()) {
		case XY:
			return acquireValue(sender, N);
		case XX:
			return requestValue(sender, N);
		default:
			return callValue(sender, N);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#revealKey(org.xmlrobot.TimeListener, java.util.concurrent.atomic.AtomicInteger)
	 */
	@Override
	public Tachyon<K,V> getKey(MassListener sender, AtomicInteger N) {
		switch (getGen()) {
		case XY:
			return requestKey(sender, N);
		case XX:
			return acquireKey(sender, N);
		default:
			return callKey(sender, N);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#revealKey(org.xmlrobot.TimeListener, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public Tachyon<K,V> getKey(MassListener sender, Tachyon<V,K> event) {
		switch (getGen()) {
		case XY:
			return requestKey(sender, event);
		case XX:
			return acquireKey(sender, event);
		default:
			return callKey(sender, event);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#revealValue(org.xmlrobot.TimeListener, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public Tachyon<V,K> getValue(MassListener sender, Tachyon<K,V> event) {
		switch (getGen()) {
		case XY:
			return acquireValue(sender, event);
		case XX:
			return requestValue(sender, event);
		default:
			return callValue(sender, event);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#pointerOfKey(org.xmlrobot.TimeListener, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public AtomicInteger indexOfKey(MassListener sender, Tachyon<K,V> event) {
		// commute by gender type
		switch (getGen()) {
		case XY:
			return positionOfKey(sender, event);
		case XX:
			return pointerOfKey(sender, event);
		default:
			return orderOfKey(sender, event);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#pointerOfValue(org.xmlrobot.TimeListener, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public AtomicInteger indexOfValue(MassListener sender, Tachyon<V,K> event) {
		switch (getGen()) {
		case XY:
			return pointerOfValue(sender, event);
		case XX:
			return positionOfValue(sender, event);
		default:
			return orderOfValue(sender, event);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#orderValue(org.xmlrobot.TimeListener, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public synchronized void orderValue(MassListener sender, Tachyon<V,K> event) {
		switch (getGen()) {
		case XY:
			orderInferValue(sender, event);
			return;
		case XX:
			orderSuperValue(sender, event);
			return;
		default:
			orderWeakValue(sender, event);
			return;
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#orderKey(org.xmlrobot.TimeListener, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public synchronized void orderKey(MassListener sender, Tachyon<K,V> event) {
		switch (getGen()) {
		case XY:
			orderSuperKey(sender, event);
			return;
		case XX:
			orderInferKey(sender, event);
			return;
		default:
			orderStrongKey(sender, event);
			return;
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#receiveKey(org.xmlrobot.TimeListener, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public Tachyon<K,V> receiveKey(MassListener sender, Tachyon<K,V> event) {
		switch (getGen()) {
		case XY:
			return borrowKey(sender, event);
		case XX:
			return takeKey(sender, event);
		default:
			return closeKey(sender, event);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#receiveValue(org.xmlrobot.TimeListener, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public Tachyon<V,K> receiveValue(MassListener sender, Tachyon<V,K> event) {
		switch (getGen()) {
		case XY:
			return takeValue(sender, event);
		case XX:
			return borrowValue(sender, event);
		default:
			return closeValue(sender, event);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#removeKey(org.xmlrobot.TimeListener)
	 */
	@Override
	public void removeKey(MassListener sender) {
		// commute by parity
		switch (getGen()) {
		case XY:
			releaseKey(sender);
			return;
		case XX:
			liberateKey(sender);
			return;
		default:
			redeemKey(sender);
			return;
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#removeValue(org.xmlrobot.TimeListener)
	 */
	@Override
	public void removeValue(MassListener sender) {
		// commute by parity
		switch (getGen()) {
		case XY:
			liberateValue(sender);
			return;
		case XX:
			releaseValue(sender);
			return;
		default:
			redeemValue(sender);
			return;
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#liberateValue(org.xmlrobot.TimeListener, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public synchronized void removeValue(MassListener sender, Tachyon<V,K> event) {
		switch (getGen()) {
		case XY:
			releaseValue(sender, event);
			return;
		case XX:
			liberateValue(sender, event);
			return;
		default:
			redeemValue(sender, event);
			return;
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#removeKey(org.xmlrobot.TimeListener, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public synchronized void removeKey(MassListener sender, Tachyon<K,V> event) {
		switch (getGen()) {
		case XY:
			liberateKey(sender, event);
			return;
		case XX:
			releaseKey(sender, event);
			return;
		default:
			redeemKey(sender, event);
			return;		
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#sendKey(org.xmlrobot.TimeListener, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public Tachyon<K,V> sendKey(MassListener sender, Tachyon<K,V> event) {
		switch (getGen()) {
		case XY:
			return giveKey(sender, event);
		case XX:
			return lendKey(sender, event);
		default:
			return openKey(sender, event);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#sendValue(org.xmlrobot.TimeListener, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public Tachyon<V,K> sendValue(MassListener sender, Tachyon<V,K> event) {
		switch (getGen()) {
		case XY:
			return lendValue(sender, event);
		case XX:
			return giveValue(sender, event);
		default:
			return openValue(sender, event);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#assignKey(org.xmlrobot.TimeListener, java.util.concurrent.atomic.AtomicInteger, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public Tachyon<K,V> setKey(MassListener sender, AtomicInteger N, Tachyon<K,V> event) {
		switch (getGen()) {
		case XY:
			return updateKey(sender, N, event);
		case XX:
			return assignKey(sender, N, event);
		default:
			return putKey(sender, N, event);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#assignValue(org.xmlrobot.TimeListener, java.util.concurrent.atomic.AtomicInteger, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public Tachyon<V,K> setValue(MassListener sender, AtomicInteger N, Tachyon<V,K> event) {
		switch (getGen()) {
		case XY:
			return assignValue(sender, N, event);
		case XX:
			return updateValue(sender, N, event);
		default:
			return putValue(sender, N, event);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#assignKey(org.xmlrobot.TimeListener, org.xmlrobot.horizon.Tachyon, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public Tachyon<K,V> setKey(MassListener sender, Tachyon<V,K> antievent, Tachyon<K,V> event) {
		switch (getGen()) {
		case XY:
			return updateKey(sender, antievent, event);
		case XX:
			return assignKey(sender, antievent, event);
		default:
			return putKey(sender, antievent, event);
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#assignValue(org.xmlrobot.TimeListener, org.xmlrobot.horizon.Tachyon, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public Tachyon<V,K> setValue(MassListener sender, Tachyon<K,V> event, Tachyon<V,K> antievent) {
		switch (getGen()) {
		case XY:
			return assignValue(sender, event, antievent);
		case XX:
			return updateValue(sender, event, antievent);
		default:
			return putValue(sender, event, antievent);
		}
	}
    /* (non-Javadoc)
     * @see org.xmlrobot.TimeListener#spinValue(org.xmlrobot.TimeListener)
     */
    @Override
	public synchronized void spinValue(MassListener sender, AtomicInteger N, Tachyon<V,K> event) {
    	switch (getGen()) {
		case XY:
			rotateValue(sender, N, event);
			return;
		case XX:
			revolveValue(sender, N, event);
			return;
		default:
			permuteValue(sender, N, event);
			return;
		}
	}
    /* (non-Javadoc)
     * @see org.xmlrobot.TimeListener#spinKey(org.xmlrobot.TimeListener)
     */
    @Override
	public synchronized void spinKey(MassListener sender, AtomicInteger N, Tachyon<K,V> event) {
    	switch (getGen()) {
		case XY:
			revolveKey(sender, N, event);
			return;
		case XX:
			rotateKey(sender, N, event);
			return;
		default:
			permuteKey(sender, N, event);
			return;
		}
    }
    /* (non-Javadoc)
     * @see org.xmlrobot.TimeListener#swapKey(org.xmlrobot.TimeListener, org.xmlrobot.horizon.Tachyon)
     */
    @Override
    public void swapKey(MassListener sender, Tachyon<K,V> event) {
    	switch (getGen()) {
		case XY:
			commuteKey(sender, event);
			return;
		case XX:
			exchangeKey(sender, event);
			return;
		default:
			switchKey(sender, event);
			return;
		}
    }
    /* (non-Javadoc)
     * @see org.xmlrobot.TimeListener#swapValue(org.xmlrobot.TimeListener, org.xmlrobot.horizon.Tachyon)
     */
    @Override
    public void swapValue(MassListener sender, Tachyon<V,K> event) {
    	switch (getGen()) {
		case XY:
			exchangeValue(sender, event);
			return;
		case XX:
			commuteValue(sender, event);
			return;
		default:
			switchValue(sender, event);
			return;
		}
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#tickKey(org.xmlrobot.TimeListener, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public void tickKey(MassListener sender, Tachyon<K,V> event) {
		switch (getGen()) {
		case XY:
			flipKey(sender, event);
			return;
		case XX:
			popKey(sender, event);
			return;
		default:
			pingKey(sender, event);
			return;
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#tickValue(org.xmlrobot.TimeListener, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public void tickValue(MassListener sender, Tachyon<V,K> event) {
		switch (getGen()) {
		case XY:
			popValue(sender, event);
			return;
		case XX:
			flipValue(sender, event);
			return;
		default:
			pingValue(sender, event);
			return;
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#tackValue(org.xmlrobot.TimeListener, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public void tackValue(MassListener sender, Tachyon<V,K> event) {
		switch (getGen()) {
		case XY:
			pollValue(sender, event);
			return;
		case XX:
			flopValue(sender, event);
			return;
		default:
			pongValue(sender, event);
			return;
		}
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.TimeListener#tackKey(org.xmlrobot.TimeListener, org.xmlrobot.horizon.Tachyon)
	 */
	@Override
	public void tackKey(MassListener sender, Tachyon<K,V> event) {
		switch (getGen()) {
		case XY:
			flopKey(sender, event);
			return;
		case XX:
			pollKey(sender, event);
			return;
		default:
			pongKey(sender, event);
			return;
		}
	}
	/**
	 * Iterator of the past implementation class. Iterates through time concurrently to the future.
	 * <p>This class is a member of the <tt>hyperspace congregation framework</tt></p>.
	 * @author joan
	 */
	protected class FutureIterator
		extends Hypergear<K,V>
	   		implements Iterator<K> {
	   	/**
	   	 * 
	   	 */
	   	public FutureIterator(K entity) {
	   		super(entity);
	   	}
	   	
	   	/*
	   	 * (non-Javadoc)
	   	 * @see java.util.Iterator#next()
	   	 */
	   	@Override
	   	public K next() {
	   		return this.forward();
	   	}
		/* (non-Javadoc)
		 * @see org.xmlrobot.time.Metaphysical.InheritanceIterator#remove()
		 */
		@Override
		public void remove() {
			K k = next;
			if(!current.isFuture()) {
		   		// remove current child from inheritance
				current.clear(root());
		   		// check if we are on the limits
				if(k != null) {
		    		current = k;
		    		next = k.call();
				}
			}
			else throw new NoSuchElementException();
		}

		/* (non-Javadoc)
		 * @see org.xmlrobot.Hypergenesis.Hypergear#hasNext()
		 */
		@Override
		public boolean hasNext() {
			return !current.isFuture();
		}

		/* (non-Javadoc)
		 * @see org.xmlrobot.Hypergenesis.Hypergear#hasMoreElements()
		 */
		@Override
		public boolean hasMoreElements() {
			return !current.isFuture();
		}
	}
	/**
	 * Iterator of the past implementation class. Iterates through time
	 * recurrently to the past.
	 * <p>This class is a member of the <tt>hyperspace congregation framework</tt></p>
	 * @author joan
	 */
	protected class PastIterator 
		extends Hypergear<K,V> 
			implements Iterator<K> {

		/**
		 * {@link PastIterator} default class constructor.
		 */
		public PastIterator(K entity) {
			super(entity);
		}

		/*
		 * (non-Javadoc)
		 * @see java.util.Iterator#next()
		 */
		@Override
		public K next() {
			return this.backward();
		}
		/*
		 * (non-Javadoc)
		 * @see org.xmlrobot.time.Metaphysical.InheritanceIterator#remove()
		 */
		@Override
		public void remove() {
			K k = next;
			if (!current.isPast()) {
				// remove current child from inheritance
				current.clear(root());
				// check if we are on the limits
				if (!k.isPast()) {
					current = k;
					next = k.getParent();
				}
			} 
			else throw new NoSuchElementException();
		}

		/* (non-Javadoc)
		 * @see org.xmlrobot.Hypergenesis.Hypergear#hasNext()
		 */
		@Override
		public boolean hasNext() {
			return !current.isPast();
		}

		/* (non-Javadoc)
		 * @see org.xmlrobot.Hypergenesis.Hypergear#hasMoreElements()
		 */
		@Override
		public boolean hasMoreElements() {
			return !current.isPast();
		}
	}
	/**
	 * Enumerator of the past implementation class. Enumerates across time
	 * recurrently to the past.
	 * <p>This class is a member of the <tt>hyperspace congregation framework</tt></p>.
	 * @author joan
	 */
	protected class PastEnumerator 
		extends Hypergear<V, K> 
			implements Enumeration<V> {

		/**
		 * @param value
		 */
		public PastEnumerator(V value) {
			super(value);
		}

		/*
		 * (non-Javadoc)
		 * @see java.util.Enumeration#nextElement()
		 */
		@Override
		public V nextElement() {
			return this.backward();
		}

		/* (non-Javadoc)
		 * @see org.xmlrobot.Hypergenesis.Hypergear#hasNext()
		 */
		@Override
		public boolean hasNext() {
			// TODO Auto-generated method stub
			return false;
		}

		/* (non-Javadoc)
		 * @see org.xmlrobot.Hypergenesis.Hypergear#hasMoreElements()
		 */
		@Override
		public boolean hasMoreElements() {
			// TODO Auto-generated method stub
			return false;
		}
	}
	/**
	 * Enumerator of the future implementation class. Enumerates across time
	 * concurrently to the future.
	 * <p>This class is a member of the <tt>hyperspace congregation framework</tt></p>.
	 * @author joan
	 */
	protected class FutureEnumerator 
		extends Hypergear<V, K> 
			implements Enumeration<V> {
		/**
		 * @param value
		 */
		public FutureEnumerator(V value) {
			super(value);
		}
		/*
		 * (non-Javadoc)
		 * @see java.util.Enumeration#nextElement()
		 */
		@Override
		public V nextElement() {
			return this.forward();
		}
		/* (non-Javadoc)
		 * @see org.xmlrobot.Hypergenesis.Hypergear#hasNext()
		 */
		@Override
		public boolean hasNext() {
			// TODO Auto-generated method stub
			return false;
		}
		/* (non-Javadoc)
		 * @see org.xmlrobot.Hypergenesis.Hypergear#hasMoreElements()
		 */
		@Override
		public boolean hasMoreElements() {
			// TODO Auto-generated method stub
			return false;
		}
	}
}