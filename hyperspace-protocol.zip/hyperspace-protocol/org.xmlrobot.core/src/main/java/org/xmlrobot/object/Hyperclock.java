/**
 * 
 */
package org.xmlrobot.object;

import org.xmlrobot.MassListener;
import org.xmlrobot.horizon.Mass;
import org.xmlrobot.metatext.Metatext;
import org.xmlrobot.util.Parity;

/**
 * @author joan
 *
 */
public abstract class Hyperclock<K,V> 
	extends Hyperlang<K,V>
		implements Metatext<K,V> {

	/**
	 * -8771534028220094958L
	 */
	private static final long serialVersionUID = -8771534028220094958L;
	
	/**
	 * {@link Hyperclock} default class constructor.
	 */
	public Hyperclock() {
		super();
	}
	/**
	 * {@link Hyperclock} class constructor.
	 * @param type the type
     * @param fromType the from type
	 * @param from the from
	 * @param to the to
	 * @param gen {@link Parity} the gender
	 */
    protected Hyperclock(
    		Class<? extends Metatext<K,V>> type, 
    		Class<K[]> fromType,
    		K from, V to,
    		Parity gen) {
		super(type, fromType, from, to, gen);
	}
	/**
	 * {@link Hyperclock} class constructor.
	 * @param type the type
	 * @param antitype the antitype
     * @param fromType the from type
	 * @param from the from
	 * @param to the to
	 * @param gen {@link Parity} the gender
	 */
    protected Hyperclock(
    		Class<? extends Metatext<K,V>> type, 
    	    Class<? extends Metatext<V,K>> antitype,
    		Class<K[]> fromType,
    		K from, V to,
    	    Parity gen) {
		super(type, instance(antitype, to, from), 
				fromType, from, to, gen);
	}
    /**
	 * {@link Hyperclock} class constructor.
	 * @param type the type
	 * @param from the from
	 * @param to the to
	 * @param parent the root
	 * @param child the stem
	 */
    protected Hyperclock(
    		Class<? extends Metatext<K,V>> type,
    		K from, V to, 
    		Metatext<K,V> parent, 
    		Metatext<V,K> child) {
		super(type, from, to, parent, child);
	}
    /**
	 * {@link Hyperclock} class constructor.
	 * @param type the type
	 * @param antitype the antitype
	 * @param from the from
	 * @param to the negative
	 * @param parent the root
	 * @param child the stem
	 */
    protected Hyperclock(
    		Class<? extends Metatext<K,V>> type,
    	    Class<? extends Metatext<V,K>> antitype, 
    		K from, V to,
    		Metatext<K,V> parent, 
    		Metatext<V,K> child) {
		super(type, instance(antitype, to, from, child, parent), 
				from, to, parent, child);
	}
    /**
	 * {@link Hyperclock} class constructor.
	 * @param type the type
	 * @param from the from
	 * @param to the to
	 * @param root the parent
	 * @param stem the child
	 * @param gen {@link Parity} the gender
	 */
    protected Hyperclock(
    		Class<? extends Metatext<K,V>> type,
    		K from, V to, 
    		Metatext<K,V> root, 
    		Metatext<V,K> stem, 
    		Parity gen) {
		super(type, from, to, root, stem, gen);
	}
    /**
	 * {@link Hyperclock} class constructor.
	 * @param type the type
	 * @param antitype the antitype
	 * @param from the from
	 * @param to the to
	 * @param root the parent
	 * @param stem the child
	 * @param gen {@link Parity} the gender
	 */
    protected Hyperclock(
    		Class<? extends Metatext<K,V>> type,
    		Class<? extends Metatext<V,K>> antitype, 
    		K from, V to,
    		Metatext<K,V> root, 
    		Metatext<V,K> stem, 
    		Parity gen) {
		super(type, instance(antitype, to, from, stem, root, Parity.opposite(gen)), 
				from, to, root, stem, gen);
	}

	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.RecurrenceMeta#hasFrom(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public boolean hasFrom(MassListener sender, Mass<K> event) {
		if(event.getSource() == getFrom()) {
			return true;
		}
		else if(isPast()) {
			return false;
		}
		else return getParent().hasFrom(sender, event);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.RecurrenceMeta#hasTo(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public boolean hasTo(MassListener sender, Mass<V> event) {
		if(event.getSource() == getTo()) {
			return true;
		}
		else if(isFuture()) {
			return false;
		}
		else return call().hasTo(sender, event);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.MetaConcurrence#holdsTo(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public boolean holdsTo(MassListener  sender, Mass<V> event) {
		if(event.getSource() == getTo()) {
			return true;
		}
		else if(isFuture()) {
			return false;
		}
		else return get().holdsFrom(sender, event);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.MetaConcurrence#holdsFrom(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public boolean holdsFrom(MassListener sender, Mass<K> event) {
		if(event.getSource() == getFrom()) {
			return true;
		}
		else if(isFuture()) {
			return false;
		}
		else return get().holdsTo(sender, event);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.MetaRecursion#belongsTo(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public boolean belongsTo(MassListener  sender, Mass<V> event) {
		if(event.getSource() == getTo()) {
			return true;
		}
		else if(isPast()) {
			return false;
		}
		else return getChild().holdsFrom(sender, event);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.metatext.MetaRecursion#belongsFrom(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass)
	 */
	@Override
	public boolean belongsFrom(MassListener sender, Mass<K> event) {
		if(event.getSource() == getFrom()) {
			return true;
		}
		else if(isPast()) {
			return false;
		}
		else return getChild().holdsTo(sender, event);
	}


	/* (non-Javadoc)
	 * @see org.xmlrobot.Hypergenesis#matrix()
	 */
	@Override
	public Metatext.Translocator<K,V> matrix() {
		Metatext.Translocator<K,V> m;
 		return (m = (Metatext.Translocator<K,V>) matrix) != null ? 
 				m : (Metatext.Translocator<K,V>) (matrix = new Hypergrid());
	}
 	/**
	 * The Hypergrid. A hyper-digital hyper-frontier. 
	 * <p>I hyper-tried to hyper-picture hyper-clusters of hyper-information as they hyper-moved through 
	 * the hyper-computer. What did they hyper-look like? Hyper-Ships, hyper-motorcycles? Were the hyper-circuits 
	 * like hyper-freeways? I kept hyper-dreaming of a hyper-world I hyper-thought I'd hyper-never see. 
	 * And then, one hypercube I got in...
	 * <p>It does the {@code hyper-future}. So, this class represents the hyper-abstract 
	 * hyper-implementation of the <tt>hypergenesis<K,V,> hyper-computation</tt>. 
	 * 
	 * @author joan
	 */
	protected class Hypergrid
		extends Grid
			implements Metatext.Translocator<K,V> {

		/**
		 * @param output
		 */
		public Hypergrid() {
			super(instance(getAntitype(), getType(), 
					getTo(), getFrom(), getStem(), getRoot(), Parity.opposite(getGen())));
		}
		
		/* (non-Javadoc)
		 * @see org.xmlrobot.Hypergenesis.Comparator#push(org.xmlrobot.genesis.TimeListener)
		 */
		@Override
		public void inject(Metatext<K,V> key) {
			// clone child
			put(key.getFrom(), key.getTo());
		}
		/* (non-Javadoc)
		 * @see org.xmlrobot.Hypergenesis.Comparator#inject(org.xmlrobot.genesis.TimeListener)
		 */
		@Override
		public void push(Metatext<V,K> value) {
			// clone child
			put(value.getTo(), value.getFrom());
		}
		/* (non-Javadoc)
		 * @see org.xmlrobot.genesis.Metatext.Translocator#put(java.lang.Object, java.lang.Object)
		 */
		@Override
		public void put(K from, V to) {
			// instantiate and run super push
			super.push(instance(getAntitype(), getType(), to, from, output().getValue(), output()));			
		}
	}
}