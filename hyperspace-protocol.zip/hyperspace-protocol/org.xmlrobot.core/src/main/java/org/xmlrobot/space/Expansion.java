/**
 * 
 */
package org.xmlrobot.space;

import org.xmlrobot.MassListener;
import org.xmlrobot.TimeListener;
import org.xmlrobot.horizon.Mass;
import org.xmlrobot.positron.Positron;
import org.xmlrobot.util.Instruction;
import org.xmlrobot.util.Parity;
import org.xmlrobot.util.Commandment;

/**
 * @author joan
 *
 */
public abstract class Expansion
	<K extends TimeListener<? super K,? super V>,
	 V extends TimeListener<? super V,? super K>>
		extends Repulsion<K,V>
			implements Positron<K,V> {

	/**
	 * 6197078208917947133L
	 */
	private static final long serialVersionUID = 6197078208917947133L;

	/**
     * {@link Expansion} default class constructor.
     */
    public Expansion() {
    	super();
    }
    /**
	 * {@link Expansion} class constructor.
	 * @param type the type
	 * @param key the key
	 * @param value the value
	 * @param gen {@link Parity} the gender
	 */
    protected Expansion(
    		Class<? extends Positron<K,V>> type, 
    		K key, V value, Parity gen) {
		super(type, key, value, gen);
	}
    /**
	 * {@link Expansion} class constructor.
	 * @param type the type
	 * @param antitype the antitype
	 * @param key the key
	 * @param value the value
	 * @param gen {@link Parity} the gender
	 */
    protected Expansion(
    		Class<? extends Positron<K,V>> type, 
    	    Class<? extends Positron<V,K>> antitype, 
    		K key, V value, Parity gen) {
		super(type, antitype, key, value, gen);
	}
    /**
	 * {@link Expansion} class constructor.
	 * @param type the type
	 * @param key the key
	 * @param value the value
	 * @param parent the parent
	 * @param child the child
	 */
    protected Expansion(
    		Class<? extends Positron<K,V>> type, 
    		K key, V value, 
    		Positron<K,V> parent,
    		Positron<V,K> child) {
		super(type, key, value, parent, child);
	}
    /**
	 * {@link Expansion} class constructor.
	 * @param type the type
	 * @param antitype the antitype
	 * @param key the key
	 * @param value the value
	 * @param parent the parent
	 * @param child the child
	 */
    protected Expansion(
    		Class<? extends Positron<K,V>> type,
    		Class<? extends Positron<V,K>> antitype,
    		K key, V value,
    		Positron<K,V> parent,
    		Positron<V,K> child) {
		super(type, antitype, key, value, parent, child);
	}
    /**
	 * {@link Expansion} class constructor.
	 * @param type the type
	 * @param key the key
	 * @param value the value
	 * @param root the root
	 * @param stem the stem
	 * @param gen {@link Parity} the gender
	 */
    protected Expansion(
    		Class<? extends Positron<K,V>> type, 
    		K key, V value, 
    		Positron<K,V> root,
    		Positron<V,K> stem,
    		Parity gen) {
		super(type, key, value, root, stem, gen);
	}
    /**
	 * {@link Expansion} class constructor.
	 * @param type the type
	 * @param antitype the antitype
	 * @param key the key
	 * @param value the value
	 * @param root the root
	 * @param stem the stem
	 * @param gen {@link Parity} the gender
	 */
    protected Expansion(
    		Class<? extends Positron<K,V>> type, 
    		Class<? extends Positron<V,K>> antitype, 
    		K key, V value,
    		Positron<K,V> root, 
    		Positron<V,K> stem,
    		Parity gen) {
		super(type, antitype, key, value, root, stem, gen);
	}
    
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassConcurrence#exploitNegativeIfAbsent(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.util.Instruction)
	 */
	@Override
    public synchronized void exploitNegativeIfAbsent(MassListener sender, Mass<K> event, 
    		Instruction<K,V> unificationFunction) {
		// check event by positive
    	if(event.getSource() == getPositive()) {
    		return;
    	}
    	// check if we arrived to the future
    	else if(isFuture()) {
    		// declare new negative
    		V newNegative;
    		// execute instruction 
    		if((newNegative = unificationFunction.apply(event.getSource())) != null){
        		// put negative
        		putNegative(sender, event, new Mass<V>(newNegative));
    		}
    		return ;
    	}
    	// call recursion
    	else get().computePositiveIfAbsent(sender, event, unificationFunction);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassConcurrence#exploitPositiveIfAbsent(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.util.Instruction)
	 */
	@Override
    public synchronized void exploitPositiveIfAbsent(MassListener sender, Mass<V> event, 
    		Instruction<V,K> unificationFunction) {
		// check event by negative
    	if(event.getSource() == getNegative()) {
    		return;
    	}
    	// check if we arrived to the future. So. it's absent.
    	else if(isFuture()) {
    		// declare new positive
    		K newPositive;
    		// execute instruction 
    		if((newPositive = unificationFunction.apply(event.getSource())) != null) {
        		// put new key-value mapping
    			putPositive(sender, event, new Mass<K>(newPositive));
    		}
    	}
    	// call recursion
    	else get().computeNegativeIfAbsent(sender, event, unificationFunction);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.RecurrenceMass#processNegativeIfAbsent(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.util.Instruction)
	 */
	@Override
    public synchronized void processNegativeIfAbsent(MassListener sender, Mass<K> event, 
    		Instruction<K,V> unificationFunction) {
		// check event by positive
    	if(event.getSource() == getPositive()) {
    		return;
    	}
    	// check if we arrived to the future
    	else if(isFuture()) {
    		// declare new negative
    		V newNegative;
    		// execute instruction 
    		if((newNegative = unificationFunction.apply(event.getSource())) != null){
        		// put negative
        		putNegative(sender, event, new Mass<V>(newNegative));
    		}
    		return ;
    	}
    	// call recursion
    	else call().computeNegativeIfAbsent(sender, event, unificationFunction);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.RecurrenceMass#processPositiveIfAbsent(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.util.Instruction)
	 */
	@Override
    public synchronized void processPositiveIfAbsent(MassListener sender, Mass<V> event, 
    		Instruction<V,K> unificationFunction) {
		// check event by negative
    	if(event.getSource() == getNegative()) {
    		return;
    	}
    	// check if we arrived to the future. So. it's absent.
    	else if(isPast()) {
    		// declare new positive
    		K newPositive;
    		// execute instruction 
    		if((newPositive = unificationFunction.apply(event.getSource())) != null) {
        		// put new key-value mapping
    			putPositive(sender, event, new Mass<K>(newPositive));
    		}
    	}
    	// call recursion
    	else getParent().computePositiveIfAbsent(sender, event, unificationFunction);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassRecursion#operateNegativeIfAbsent(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.util.Instruction)
	 */
	@Override
    public synchronized void operateNegativeIfAbsent(MassListener sender, Mass<K> event, 
    		Instruction<K,V> unificationFunction) {
		// check event by positive
    	if(event.getSource() == getPositive()) {
    		return;
    	}
    	// check if we arrived to the future
    	else if(isPast()) {
    		// declare new negative
    		V newNegative;
    		// execute instruction 
    		if((newNegative = unificationFunction.apply(event.getSource())) != null){
        		// put negative
        		putNegative(sender, event, new Mass<V>(newNegative));
    		}
    		return ;
    	}
    	// call recursion
    	else getChild().computePositiveIfAbsent(sender, event, unificationFunction);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassRecursion#operatePositiveIfAbsent(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.util.Instruction)
	 */
	@Override
    public synchronized void operatePositiveIfAbsent(MassListener sender, Mass<V> event, 
    		Instruction<V,K> unificationFunction) {
		// check event by negative
    	if(event.getSource() == getNegative()) {
    		return;
    	}
    	// check if we arrived to the future. So. it's absent.
    	else if(isPast()) {
    		// declare new positive
    		K newPositive;
    		// execute instruction 
    		if((newPositive = unificationFunction.apply(event.getSource())) != null) {
        		// put new key-value mapping
    			putPositive(sender, event, new Mass<K>(newPositive));
    		}
    	}
    	// call recursion
    	else getChild().computeNegativeIfAbsent(sender, event, unificationFunction);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassConcurrence#exploitNegative(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.util.Commandment)
	 */
	@Override
    public synchronized void exploitNegative(MassListener sender, Mass<K> event, 
    		Commandment<K,V> unificationFunction) {

		// check event by positive
        if(event.getSource() == getPositive()) {
        	// declare value
            V newValue;
            // apply and check result existence
            if ((newValue = unificationFunction.apply(event.getSource(), getNegative())) == null) {
            	// something to make free
                clear(sender);
            }
            else {
                // allocate or replace old unification
                setNegative(newValue);
            }
        }
    	// check if we arrived to the future
        else if(isPast()) {
    		return ;
        }
        // call recursion
        else get().computePositive(sender, event, unificationFunction);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassConcurrence#exploitPositive(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.util.Commandment)
	 */
	@Override
    public synchronized void exploitPositive(MassListener sender, Mass<V> event, 
    		Commandment<V,K> unificationFunction) {
		// check event by negative
        if(event.getSource() == getNegative()) {
        	// declare new key
            K newKey;
            // apply and check result existence
            if ((newKey = unificationFunction.apply(event.getSource(), getPositive())) == null) {
                // delete positron
            	clear(sender);
            } else {
                // add or replace old unification
                setPositive(newKey);
            }
        }
    	// check if we arrived to the future
        else if(isFuture()){
        	return ;
        }
        // call recursion
        else get().computeNegative(sender, event, unificationFunction);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.RecurrenceMass#processNegative(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.util.Commandment)
	 */
	@Override
    public synchronized void processNegative(MassListener sender, Mass<K> event, 
    		Commandment<K,V> unificationFunction) {
		// check event by positive
        if(event.getSource() == getPositive()) {
        	// declare value
            V newValue;
            // apply and check result existence
            if ((newValue = unificationFunction.apply(event.getSource(), getNegative())) == null) {
            	// something to make free
                clear(sender);
            }
            else {
                // allocate or replace old unification
                setNegative(newValue);
            }
        }
    	// check if we arrived to the future
        else if(isFuture()) {
    		return ;
        }
        // call recursion
        else call().computeNegative(sender, event, unificationFunction);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.RecurrenceMass#processPositive(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.util.Commandment)
	 */
	@Override
    public synchronized void processPositive(MassListener sender, Mass<V> event, 
    		Commandment<V,K> unificationFunction) {
		// check event by negative
        if(event.getSource() == getNegative()) {
        	// declare new key
            K newKey;
            // apply and check result existence
            if ((newKey = unificationFunction.apply(event.getSource(), getPositive())) == null) {
                // delete positron
            	clear(sender);
            } else {
                // add or replace old unification
                setPositive(newKey);
            }
        }
    	// check if we arrived to the future
        else if(isPast()){
        	return ;
        }
        // call recursion
        else getParent().computePositive(sender, event, unificationFunction);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassRecursion#operateNegative(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.util.Commandment)
	 */
	@Override
    public synchronized void operateNegative(MassListener sender, Mass<K> event, 
    		Commandment<K,V> unificationFunction) {
		// check event by positive
        if(event.getSource() == getPositive()) {
        	// declare value
            V newValue;
            // apply and check result existence
            if ((newValue = unificationFunction.apply(event.getSource(), getNegative())) == null) {
            	// something to make free
                clear(sender);
            }
            else {
                // allocate or replace old unification
                setNegative(newValue);
            }
        }
    	// check if we arrived to the future
        else if(isPast()) {
    		return ;
        }
        // call recursion
        else getChild().computePositive(sender, event, unificationFunction);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.positron.MassRecursion#operatePositive(org.xmlrobot.MassListener, org.xmlrobot.horizon.Mass, org.xmlrobot.util.Commandment)
	 */
	@Override
    public synchronized void operatePositive(MassListener sender, Mass<V> event, 
    		Commandment<V,K> unificationFunction) {
		// check event by negative
        if(event.getSource() == getNegative()) {
        	// declare new key
            K newKey;
            // apply and check result existence
            if ((newKey = unificationFunction.apply(event.getSource(), getPositive())) == null) {
                // delete positron
            	clear(sender);
            } else {
                // add or replace old unification
                setPositive(newKey);
            }
        }
    	// check if we arrived to the future
        else if(isPast()){
        	return ;
        }
        // call recursion
        else getChild().computeNegative(sender, event, unificationFunction);
    }
}