/**
 * 
 */
package org.xmlrobot.space;

import java.util.Collection;

import javax.xml.bind.annotation.XmlTransient;

import org.xmlrobot.MassListener;
import org.xmlrobot.TimeListener;
import org.xmlrobot.horizon.Graviton;
import org.xmlrobot.horizon.Mass;
import org.xmlrobot.positron.Positron;
import org.xmlrobot.util.Parity;

/**
 * @author joan
 *
 */
public abstract class Space
	<K extends TimeListener<? super K,? super V>,
	 V extends TimeListener<? super V,? super K>>
		extends Expansion<K,V>
			implements Positron<K,V> {

	/**
	 * -1869400212817371232L
	 */
	private static final long serialVersionUID = -1869400212817371232L;
	
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.Positron#getPositive()
	 */
	@Override
	@XmlTransient
	public K getPositive() {
		return super.getPositive();
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.Positron#setPositive(java.lang.Object)
	 */
	@Override
	public K setPositive(K key) {
		// update key
		K oldKey = super.setPositive(key);
		// check key existence
		if(key != null) {
			// ancestral callback
			key.addMassListener(getValue());
		}
		// check old key existence
		if(oldKey != null) {
			// stop listening prayers
			oldKey.removeMassListener(getValue());
		}
		// return old key
		return oldKey;
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.Positron#getNegative()
	 */
	@Override
	@XmlTransient
	public V getNegative() {
		return super.getNegative();
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.Positron#setNegative(java.lang.Object)
	 */
	@Override
	public V setNegative(V value) {
		// update value
		V oldValue = super.setNegative(value);
		// check value existence
		if(value != null) {
			// ancestral callback
			value.addMassListener(getKey());
		}
		// check old value existence
		if(oldValue != null) {
			// stop listening prayers
			oldValue.removeMassListener(getKey());
		}
		// return old value
		return oldValue;
	}
	
	/**
     * {@link Space} default class constructor.
     */
    public Space() {
    	super();
    }
    /**
	 * {@link Space} class constructor.
	 * @param type the type
	 * @param key the key
	 * @param value the value
	 * @param gen {@link Parity} the gender
	 */
    protected Space(
    		Class<? extends Positron<K,V>> type, 
    		K key, V value, Parity gen) {
		super(type, key, value, gen);
	}
    /**
	 * {@link Space} class constructor.
	 * @param type the type
	 * @param antitype the antitype
	 * @param key the key
	 * @param value the value
	 * @param gen {@link Parity} the gender
	 */
    protected Space(
    		Class<? extends Positron<K,V>> type, 
    	    Class<? extends Positron<V,K>> antitype, 
    		K key, V value, Parity gen) {
		super(type, antitype, key, value, gen);
		// listen value's mass
		value.addMassListener(this);
	}
    /**
	 * {@link Space} class constructor.
	 * @param type the type
	 * @param key the key
	 * @param value the value
	 * @param parent the parent
	 * @param child the child
	 */
    protected Space(
    		Class<? extends Positron<K,V>> type, 
    		K key, V value, 
    		Positron<K,V> parent, 
    		Positron<V,K> child) {
		super(type, key, value, parent, child);
		// listen value's mass
		value.addMassListener(this);
	}
    /**
	 * {@link Space} class constructor.
	 * @param type the type
	 * @param antitype the antitype
	 * @param key the key
	 * @param value the value
	 * @param parent the parent
	 * @param child the child
	 */
    protected Space(
    		Class<? extends Positron<K,V>> type, 
    		Class<? extends Positron<V,K>> antitype, 
    		K key, V value,
    		Positron<K,V> parent, 
    		Positron<V,K> child) {
		super(type, antitype, key, value, parent, child);
		// listen value's mass
		value.addMassListener(this);
	}
    /**
	 * {@link Space} class constructor.
	 * @param type the type
	 * @param key the key
	 * @param value the value
	 * @param root the root
	 * @param stem the stem
	 * @param gen {@link Parity} the gender
	 */
    protected Space(
    		Class<? extends Positron<K,V>> type, 
    		K key, V value, 
    		Positron<K,V> root, 
    		Positron<V,K> stem,
    		Parity gen) {
		super(type, key, value, root, stem, gen);
		// listen value's mass
		value.addMassListener(this);
	}
    /**
	 * {@link Space} class constructor.
	 * @param type the type
	 * @param antitype the antitype
	 * @param key the key
	 * @param value the value
	 * @param root the root
	 * @param stem the stem
	 * @param gen {@link Parity} the gender
	 */
    protected Space(
    		Class<? extends Positron<K,V>> type, 
    		Class<? extends Positron<V,K>> antitype, 
    		K key, V value,
    		Positron<K,V> root, 
    		Positron<V,K> stem,
    		Parity gen) {
		super(type, antitype, key, value, root, stem, gen);
		// listen value's mass
		value.addMassListener(this);
	}

	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.PastMass#getNegative(org.xmlrobot.genesis.MassListener, org.xmlrobot.horizon.Boson)
	 */
	@Override
    public Mass<V> acquireNegative(MassListener sender, Mass<K> event) {
		if(event.getSource() == getPositive()) {
        	return newNegative();
        }
        else if(isFuture()) {
        	return null;
        }
        else return get().acquirePositive(sender, event);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.MassFuture#getPositive(org.xmlrobot.genesis.MassListener, org.xmlrobot.horizon.Boson)
	 */
	@Override
    public Mass<K> acquirePositive(MassListener sender, Mass<V> event) {
		if(event.getSource() == getNegative()) {
        	return newPositive();
        }
        else if(isFuture()) {
        	return null;
        }
        else return get().acquireNegative(sender, event);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.PastMass#getNegative(org.xmlrobot.genesis.MassListener, org.xmlrobot.horizon.Boson)
	 */
	@Override
    public Mass<V> callNegative(MassListener sender, Mass<K> event) {
		if(event.getSource() == getPositive()) {
        	return newNegative();
        }
        else if(isFuture()) {
        	return null;
        }
        else return call().callNegative(sender, event);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.MassFuture#getPositive(org.xmlrobot.genesis.MassListener, org.xmlrobot.horizon.Boson)
	 */
	@Override
    public Mass<K> callPositive(MassListener sender, Mass<V> event) {
		if(event.getSource() == getNegative()) {
        	return newPositive();
        }
        else if(isPast()) {
        	return null;
        }
        else return getParent().callPositive(sender, event);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.PastMass#getNegative(org.xmlrobot.genesis.MassListener, org.xmlrobot.horizon.Boson)
	 */
	@Override
    public Mass<V> requestNegative(MassListener sender, Mass<K> event) {
		if(event.getSource() == getPositive()) {
        	return newNegative();
        }
        else if(isPast()) {
        	return null;
        }
        else return getChild().acquirePositive(sender, event);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.MassFuture#getPositive(org.xmlrobot.genesis.MassListener, org.xmlrobot.horizon.Boson)
	 */
	@Override
    public Mass<K> requestPositive(MassListener sender, Mass<V> event) {
		if(event.getSource() == getNegative()) {
        	return newPositive();
        }
        else if(isPast()) {
        	return null;
        }
        else return getChild().acquireNegative(sender, event);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.CallableMass#getNegativeOrDefault(org.xmlrobot.genesis.MassListener, org.xmlrobot.horizon.Boson, org.xmlrobot.horizon.Boson)
	 */
	@Override
    public Mass<V> acquireNegativeOrDefault(MassListener sender, Mass<K> event, Mass<V> defaultEvent) {
		if(event.getSource() == getPositive()) {
        	return newNegative();
        }
        else if(isFuture()) {
        	return defaultEvent;
        }
        else return get().acquirePositiveOrDefault(sender, event, defaultEvent);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.MassRunnable#getPositiveOrDefault(org.xmlrobot.genesis.MassListener, org.xmlrobot.horizon.Boson, org.xmlrobot.horizon.Boson)
	 */
	@Override
    public Mass<K> acquirePositiveOrDefault(MassListener sender, Mass<V> event, Mass<K> defaultEvent) {
		if(event.getSource() == getNegative()) {
        	return newPositive();
        }
        else if(isFuture()) {
        	return defaultEvent;
        }
        else return get().acquireNegativeOrDefault(sender, event, defaultEvent);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.CallableMass#getNegativeOrDefault(org.xmlrobot.genesis.MassListener, org.xmlrobot.horizon.Boson, org.xmlrobot.horizon.Boson)
	 */
	@Override
    public Mass<V> callNegativeOrDefault(MassListener sender, Mass<K> event, Mass<V> defaultEvent) {
		if(event.getSource() == getPositive()) {
        	return newNegative();
        }
        else if(isFuture()) {
        	return defaultEvent;
        }
        else return call().callNegativeOrDefault(sender, event, defaultEvent);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.MassRunnable#getPositiveOrDefault(org.xmlrobot.genesis.MassListener, org.xmlrobot.horizon.Boson, org.xmlrobot.horizon.Boson)
	 */
	@Override
    public Mass<K> callPositiveOrDefault(MassListener sender, Mass<V> event, Mass<K> defaultEvent) {
		if(event.getSource() == getNegative()) {
        	return newPositive();
        }
        else if(isPast()) {
        	return defaultEvent;
        }
        else return getParent().callPositiveOrDefault(sender, event, defaultEvent);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.CallableMass#getNegativeOrDefault(org.xmlrobot.genesis.MassListener, org.xmlrobot.horizon.Boson, org.xmlrobot.horizon.Boson)
	 */
	@Override
    public Mass<V> requestNegativeOrDefault(MassListener sender, Mass<K> event, Mass<V> defaultEvent) {
		if(event.getSource() == getPositive()) {
        	return newNegative();
        }
        else if(isPast()) {
        	return defaultEvent;
        }
        else return getChild().acquirePositiveOrDefault(sender, event, defaultEvent);
    }
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.MassRunnable#getPositiveOrDefault(org.xmlrobot.genesis.MassListener, org.xmlrobot.horizon.Boson, org.xmlrobot.horizon.Boson)
	 */
	@Override
    public Mass<K> requestPositiveOrDefault(MassListener sender, Mass<V> event, Mass<K> defaultEvent) {
		if(event.getSource() == getNegative()) {
        	return newPositive();
        }
        else if(isPast()) {
        	return defaultEvent;
        }
        else return getChild().acquireNegativeOrDefault(sender, event, defaultEvent);
    }

	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.PastMass#getByPositive(org.xmlrobot.genesis.MassListener, org.xmlrobot.horizon.Boson)
	 */
	@Override
	public Graviton<K,V> acquireByPositive(MassListener sender, Mass<K> event) {
		if(event.getSource() == getPositive()) {
			return newInstant();
		}
		else if(isFuture()) {
			return null;
		}
		else return get().acquireByNegative(sender, event);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.MassFuture#getByNegative(org.xmlrobot.genesis.MassListener, org.xmlrobot.horizon.Boson)
	 */
	@Override
	public Graviton<V,K> acquireByNegative(MassListener sender, Mass<V> event) {
		if(event.getSource() == getNegative()) {
			return newFlop();
		}
		else if(isFuture()) {
			return null;
		}
		else return get().acquireByPositive(sender, event);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.PastMass#getByPositive(org.xmlrobot.genesis.MassListener, org.xmlrobot.horizon.Boson)
	 */
	@Override
	public Graviton<K,V> callByPositive(MassListener sender, Mass<K> event) {
		if(event.getSource() == getPositive()) {
			return newInstant();
		}
		else if(isPast()) {
			return null;
		}
		else return getParent().callByPositive(sender, event);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.MassFuture#getByNegative(org.xmlrobot.genesis.MassListener, org.xmlrobot.horizon.Boson)
	 */
	@Override
	public Graviton<V,K> callByNegative(MassListener sender, Mass<V> event) {
		if(event.getSource() == getNegative()) {
			return newFlop();
		}
		else if(isFuture()) {
			return null;
		}
		else return call().callByNegative(sender, event);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.PastMass#getByPositive(org.xmlrobot.genesis.MassListener, org.xmlrobot.horizon.Boson)
	 */
	@Override
	public Graviton<K,V> requestByPositive(MassListener sender, Mass<K> event) {
		if(event.getSource() == getPositive()) {
			return newInstant();
		}
		else if(isPast()) {
			return null;
		}
		else return getChild().acquireByNegative(sender, event);
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.MassFuture#getByNegative(org.xmlrobot.genesis.MassListener, org.xmlrobot.horizon.Boson)
	 */
	@Override
	public Graviton<V,K> requestByNegative(MassListener sender, Mass<V> event) {
		if(event.getSource() == getNegative()) {
			return newFlop();
		}
		else if(isPast()) {
			return null;
		}
		else return getChild().acquireByPositive(sender, event);
	}
	
	/* (non-Javadoc)
	 * @see org.xmlrobot.hyperspace.Concurrence#run()
	 */
	@Override
	public void run() {
		super.run();
		// listen time
		getNegative().start(getContext());
	}
	

	
    /**
     * this field is initialized to contain an instance of the
     * appropriate pole the first time this pole is requested.  The poles are
     * stateless, so there's no reason to create more than one.
     */
	transient volatile Collection<V> pole;

	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.Par#keyVisor()
	 */
	@Override
	public Collection<K> positive() {
		return getValue().negative();
	}
	/* (non-Javadoc)
	 * @see org.xmlrobot.genesis.Par#valueVisor()
	 */
	@Override
	public Collection<V> negative() {
		Collection<V> p;
		return (p = pole) == null ? (p = new MassCollection()) : p;
	}
}