/**
 * 
 */
package org.xmlrobot.common;

import org.xmlrobot.TimeListener;
import org.xmlrobot.horizon.Tachyon;

/**
 * @author joan
 *
 */
public class Flop extends Tachyon<Tack, Tick> {

	/**
	 * 2600741605410973198L
	 */
	private static final long serialVersionUID = 2600741605410973198L;

	/**
	 * @param source
	 */
	public Flop(TimeListener<Tack, Tick> source) {
		super(source);
		// TODO Auto-generated constructor stub
	}

}
